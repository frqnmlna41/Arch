<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * PATCH: Tambah kolom coach_id ke tabel athletes.
 *
 * Masalah:
 *   - Athlete::coach() dan scopeByCoach() menggunakan kolom coach_id
 *   - coach_id di-comment-out dari $fillable, kemungkinan juga belum ada di DB
 *   - Hasil: coach() selalu return null, scopeByCoach() throw SQL error
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('athletes', function (Blueprint $table) {
            if (! Schema::hasColumn('athletes', 'coach_id')) {
                $table->foreignId('coach_id')
                    ->nullable()
                    ->after('user_id')
                    ->constrained('users')
                    ->nullOnDelete();
            }
        });
    }

    public function down(): void
    {
        Schema::table('athletes', function (Blueprint $table) {
            if (Schema::hasColumn('athletes', 'coach_id')) {
                $table->dropForeign(['coach_id']);
                $table->dropColumn('coach_id');
            }
        });
    }
};

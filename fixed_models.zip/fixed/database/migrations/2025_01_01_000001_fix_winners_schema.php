<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * PATCH: Selesaikan migrasi setengah jalan di tabel winners.
 *
 * Masalah:
 *   - $fillable Winner sudah menggunakan event_category_id
 *   - Tapi relasi aktif masih expect event_id, discipline_id, age_category_id
 *   - Semua 3 relasi tersebut silently return null
 *
 * Solusi:
 *   - Tambah FK event_category_id jika belum ada
 *   - Hapus kolom redundan event_id, discipline_id, age_category_id
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('winners', function (Blueprint $table) {
            // Tambah FK event_category_id jika belum ada
            if (! Schema::hasColumn('winners', 'event_category_id')) {
                $table->foreignId('event_category_id')
                    ->after('id')
                    ->constrained()
                    ->cascadeOnDelete();
            }

            // Hapus kolom redundan jika masih ada
            $redundant = ['event_id', 'discipline_id', 'age_category_id'];

            foreach ($redundant as $col) {
                if (Schema::hasColumn('winners', $col)) {
                    // Drop FK dulu jika ada
                    try {
                        $table->dropForeign([$col]);
                    } catch (\Throwable) {
                        // Tidak ada FK — lanjut
                    }
                    $table->dropColumn($col);
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('winners', function (Blueprint $table) {
            // Rollback: kembalikan kolom lama
            $table->foreignId('event_id')->nullable()->constrained();
            $table->foreignId('discipline_id')->nullable()->constrained();
            $table->foreignId('age_category_id')->nullable()->constrained();

            if (Schema::hasColumn('winners', 'event_category_id')) {
                $table->dropForeign(['event_category_id']);
                $table->dropColumn('event_category_id');
            }
        });
    }
};

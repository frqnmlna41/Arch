<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * PATCH: Pastikan tabel contest_results ada dan benar.
 *
 * Masalah:
 *   - ContestResult.php mendefinisikan class TaoluScore (duplikat fatal)
 *   - Setelah fix, ContestResult membutuhkan tabel contest_results
 *
 * Jika tabel sudah ada dengan skema berbeda, sesuaikan migration ini.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('contest_results')) {
            Schema::create('contest_results', function (Blueprint $table) {
                $table->id();
                $table->foreignId('contest_id')->constrained()->cascadeOnDelete();
                $table->foreignId('recorded_by')->nullable()->constrained('users')->nullOnDelete();
                $table->text('result_notes')->nullable();
                $table->timestamp('recorded_at')->nullable();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('contest_results');
    }
};

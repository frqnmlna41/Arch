<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Skor Taolu dengan sistem 5 juri trimmed-mean.
 * Digunakan untuk cabang PERFORMANCE (Taolu/Jurus).
 *
 * Untuk cabang SPARRING (per-judge, per-round) → gunakan ContestScore.
 *
 * FIX (CRLF): File dikonversi dari Windows CRLF ke Unix LF.
 * FIX (STATUS_DONE): Konstanta dipindahkan ke model ini karena Contest
 *   tidak mendefinisikan STATUS_DONE. Jika Contest sudah punya konstanta
 *   tersebut, hapus baris STATUS_DONE di sini dan gunakan Contest::STATUS_DONE.
 */
class TaoluScore extends Model
{
    // ── Status constants (digunakan oleh saveWithFinalScore) ───────
    // BUG FIX: Contest::STATUS_DONE tidak ada → definisikan di sini,
    // atau tambahkan ke Contest. Pilih salah satu dan konsisten.
    const STATUS_DONE = 'done';

    protected $table = 'taolu_scores';

    protected $fillable = [
        'contest_id',
        'judge_1',
        'judge_2',
        'judge_3',
        'judge_4',
        'judge_5',
        'deduction',
        'final_score',
        'inputted_by',
        'inputted_at',
    ];

    protected $casts = [
        'judge_1'     => 'decimal:2',
        'judge_2'     => 'decimal:2',
        'judge_3'     => 'decimal:2',
        'judge_4'     => 'decimal:2',
        'judge_5'     => 'decimal:2',
        'deduction'   => 'decimal:2',
        'final_score' => 'decimal:3',
        'inputted_at' => 'datetime',
    ];

    // ── Relationships ──────────────────────────────────────────────

    public function contest(): BelongsTo
    {
        return $this->belongsTo(Contest::class);
    }

    public function inputter(): BelongsTo
    {
        return $this->belongsTo(User::class, 'inputted_by');
    }

    // ── Business Logic ─────────────────────────────────────────────

    /**
     * Hitung final score Taolu:
     * Buang nilai tertinggi & terendah dari 5 juri,
     * jumlahkan 3 sisanya, kurangi deduction.
     */
    public function calculateFinalScore(): float
    {
        $scores = collect([
            $this->judge_1,
            $this->judge_2,
            $this->judge_3,
            $this->judge_4,
            $this->judge_5,
        ])->filter()->sort()->values();

        // Minimal 3 nilai juri untuk dihitung
        if ($scores->count() < 3) {
            return 0.0;
        }

        // Buang tertinggi & terendah
        $trimmed = $scores->slice(1, $scores->count() - 2);

        return round($trimmed->sum() - ($this->deduction ?? 0), 3);
    }

    /**
     * Simpan dan update final_score otomatis, lalu tandai contest selesai.
     *
     * BUG FIX: Contest::STATUS_DONE tidak ada sebagai konstanta di Contest.
     * Sekarang menggunakan self::STATUS_DONE. Jika Contest ditambahkan
     * konstanta STATUS_DONE, ganti kembali ke Contest::STATUS_DONE.
     */
    public function saveWithFinalScore(): void
    {
        $this->final_score = $this->calculateFinalScore();
        $this->inputted_at = now();
        $this->inputted_by = auth()->id();
        $this->save();

        // Update status contest jadi done
        $this->contest->update(['status' => self::STATUS_DONE]);
    }
}

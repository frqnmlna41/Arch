<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Hasil akhir sebuah contest (satu baris per contest).
 * Model ini BERBEDA dengan TaoluScore:
 *   - TaoluScore  → skor mentah per juri (5-judge panel, untuk Taolu/performance)
 *   - ContestResult → hasil akhir contest (winner, ranking, catatan wasit)
 *
 * Sebelumnya file ini salah mendefinisikan class TaoluScore (duplikat fatal).
 * BUG FIX: class direname menjadi ContestResult sesuai nama file.
 */
class ContestResult extends Model
{
    protected $table = 'contest_results';

    protected $fillable = [
        'contest_id',
        'recorded_by',
        'result_notes',
        'recorded_at',
    ];

    protected $casts = [
        'recorded_at' => 'datetime',
    ];

    // ── Relationships ──────────────────────────────────────────────

    public function contest(): BelongsTo
    {
        return $this->belongsTo(Contest::class);
    }

    public function recorder(): BelongsTo
    {
        return $this->belongsTo(User::class, 'recorded_by');
    }
}

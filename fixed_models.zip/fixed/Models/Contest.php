<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Carbon\Carbon;

class Contest extends Model
{
    // ── Status constants ───────────────────────────────────────────
    // BUG FIX: Tambahkan konstanta STATUS_DONE yang direferensikan
    // oleh TaoluScore::saveWithFinalScore().
    const STATUS_PENDING = 'pending';
    const STATUS_ONGOING = 'ongoing';
    const STATUS_DONE    = 'done';
    const STATUS_SKIP    = 'skip';

    // ── Properties ─────────────────────────────────────────────────
    protected $fillable = [
        'event_category_id',
        'athlete_id',
        'registration_id',
        'discipline_id',
        'age_category_id',
        'competition_session_id',
        'appearance_order',
        'status',
    ];

    protected $casts = [
        'appearance_order' => 'integer',
    ];

    // ── Relationships ──────────────────────────────────────────────

    public function eventCategory(): BelongsTo
    {
        return $this->belongsTo(EventCategory::class);
    }

    public function athlete(): BelongsTo
    {
        return $this->belongsTo(Athlete::class);
    }

    public function registration(): BelongsTo
    {
        return $this->belongsTo(Registration::class);
    }

    public function session(): BelongsTo
    {
        return $this->belongsTo(CompetitionSession::class, 'competition_session_id');
    }

    public function score(): HasOne
    {
        return $this->hasOne(TaoluScore::class);
    }

    public function arena(): BelongsTo
    {
        return $this->belongsTo(Arena::class);
    }

    // ── Business Logic ─────────────────────────────────────────────

    /**
     * Estimasi jam tampil atlet ini.
     *
     * BUG FIX: Sebelumnya menggunakan $this->order_number yang tidak ada
     * di $fillable. Kolom yang benar adalah appearance_order.
     */
    public function estimatedTime(): ?Carbon
    {
        if (! $this->session || ! $this->appearance_order) {
            return null;
        }

        return $this->session->estimatedTimeForOrder($this->appearance_order);
    }

    public function isScored(): bool
    {
        return $this->score !== null && $this->score->final_score !== null;
    }
}

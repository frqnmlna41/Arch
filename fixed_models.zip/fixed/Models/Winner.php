<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

/**
 * Pemenang akhir dalam sebuah kategori event.
 * Diisi setelah seluruh pertandingan dalam kategori selesai.
 *
 * Rank 1 = Juara 1 (Medali Emas)
 * Rank 2 = Juara 2 (Medali Perak)
 * Rank 3 = Juara 3 (Medali Perunggu — bisa ada 2 untuk double bronze)
 *
 * BUG FIX: $fillable sebelumnya hanya berisi 'event_category_id' (hasil
 * migrasi setengah jalan), tapi relasi aktif menggunakan event_id,
 * discipline_id, dan age_category_id → semua relasi silently return null.
 *
 * Solusi: selesaikan migrasi ke skema event_category_id.
 * Winner cukup menyimpan event_category_id + athlete_id.
 * event, discipline, ageCategory diambil via eventCategory (no extra columns).
 *
 * Migration yang dibutuhkan:
 *   $table->foreignId('event_category_id')->constrained();
 *   // Hapus kolom event_id, discipline_id, age_category_id jika masih ada.
 */
class Winner extends Model
{
    use HasFactory;

    protected $table = 'winners';

    // ── Fillable ───────────────────────────────────────────────────
    protected $fillable = [
        'event_category_id',   // ✅ FK utama — sudah benar
        'athlete_id',
        'rank',
        'total_score',
        'medal_type',
        'notes',
    ];

    // ── Casts ──────────────────────────────────────────────────────
    protected $casts = [
        'rank'        => 'integer',
        'total_score' => 'decimal:3',
    ];

    // ── Constants ──────────────────────────────────────────────────
    const MEDAL_GOLD   = 'gold';
    const MEDAL_SILVER = 'silver';
    const MEDAL_BRONZE = 'bronze';

    const RANK_MEDAL_MAP = [
        1 => self::MEDAL_GOLD,
        2 => self::MEDAL_SILVER,
        3 => self::MEDAL_BRONZE,
    ];

    // ── Relationships ──────────────────────────────────────────────

    /**
     * Kategori event (mengandung event_id, discipline_id, age_category_id).
     * Gunakan ini sebagai sumber kebenaran tunggal.
     *
     * BUG FIX: Relasi event(), discipline(), ageCategory() dihapus
     * karena kolom event_id / discipline_id / age_category_id tidak
     * ada di tabel winners. Akses via eventCategory()->event, dll.
     */
    public function eventCategory(): BelongsTo
    {
        return $this->belongsTo(EventCategory::class);
    }

    /**
     * Atlet yang memenangkan posisi ini.
     */
    public function athlete(): BelongsTo
    {
        return $this->belongsTo(Athlete::class);
    }

    /**
     * Sertifikat yang dihasilkan untuk pemenang ini.
     */
    public function certificate(): HasOne
    {
        return $this->hasOne(Certificate::class);
    }

    // ── Accessor shortcuts (via eventCategory) ─────────────────────

    /**
     * Ambil Event via eventCategory (tanpa kolom event_id di winners).
     * Contoh: $winner->event->name
     */
    public function getEventAttribute(): ?Event
    {
        return $this->eventCategory?->event;
    }

    public function getDisciplineAttribute(): ?Discipline
    {
        return $this->eventCategory?->discipline;
    }

    public function getAgeCategoryAttribute(): ?AgeCategory
    {
        return $this->eventCategory?->ageCategory;
    }

    // ── Scopes ─────────────────────────────────────────────────────

    public function scopeGold($query)
    {
        return $query->where('rank', 1);
    }

    public function scopeSilver($query)
    {
        return $query->where('rank', 2);
    }

    public function scopeBronze($query)
    {
        return $query->where('rank', 3);
    }

    /**
     * Filter berdasarkan event.
     * BUG FIX: Sebelumnya where('event_id', ...) — kolom tidak ada.
     * Diganti ke whereHas via eventCategory.
     */
    public function scopeForEvent($query, int $eventId)
    {
        return $query->whereHas('eventCategory', fn ($q) =>
            $q->where('event_id', $eventId)
        );
    }

    public function scopeForDiscipline($query, int $disciplineId)
    {
        return $query->whereHas('eventCategory', fn ($q) =>
            $q->where('discipline_id', $disciplineId)
        );
    }

    // ── Accessors & Helpers ────────────────────────────────────────

    public function getMedalLabelAttribute(): string
    {
        return match ($this->rank) {
            1       => '🥇 Juara 1 (Emas)',
            2       => '🥈 Juara 2 (Perak)',
            3       => '🥉 Juara 3 (Perunggu)',
            default => "Juara {$this->rank}",
        };
    }

    public function isGold(): bool   { return $this->rank === 1; }
    public function isSilver(): bool { return $this->rank === 2; }
    public function isBronze(): bool { return $this->rank === 3; }

    public function hasCertificate(): bool
    {
        return $this->certificate()->exists();
    }
}

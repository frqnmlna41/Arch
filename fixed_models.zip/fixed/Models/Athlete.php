<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Athlete extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'user_id',
        'coach_id',        // BUG FIX: di-uncomment — kolom ini dipakai oleh
                           // coach() dan scopeByCoach(). Jika memang dihapus
                           // dari skema, hapus juga kedua method di bawah.
        'perguruan_id',
        'name',
        'birth_date',
        'gender',
        'club',
        'phone',
        'photo',
        'id_card_number',
        'weight',
        'height',
        'address',
        'is_active',
    ];

    protected $casts = [
        'birth_date' => 'date',
        'weight'     => 'decimal:2',
        'height'     => 'decimal:2',
        'is_active'  => 'boolean',
    ];

    // ── Relationships ──────────────────────────────────────────────

    /**
     * Akun user milik atlet (jika atlet punya akun sendiri).
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * Coach yang mendaftarkan atlet ini.
     *
     * BUG FIX: coach_id sebelumnya di-comment-out dari $fillable
     * sehingga kolom tidak bisa diisi dan relasi ini selalu null.
     * Aktifkan coach_id di $fillable dan di migration.
     */
    public function coach(): BelongsTo
    {
        return $this->belongsTo(User::class, 'coach_id');
    }

    /**
     * Perguruan tempat atlet terdaftar.
     */
    public function perguruan(): BelongsTo
    {
        return $this->belongsTo(Perguruan::class, 'perguruan_id');
    }

    /**
     * Disiplin-disiplin yang diikuti atlet (many-to-many via pivot athlete_discipline).
     */
    public function disciplines(): BelongsToMany
    {
        return $this->belongsToMany(Discipline::class, 'athlete_discipline')
            ->withPivot('age_category_id')
            ->withTimestamps();
    }

    /**
     * Age categories yang dipilih atlet (via pivot athlete_discipline).
     */
    public function ageCategories(): BelongsToMany
    {
        return $this->belongsToMany(AgeCategory::class, 'athlete_discipline')
            ->withPivot('discipline_id')
            ->withTimestamps();
    }

    /**
     * Semua registrasi kompetisi milik atlet ini.
     */
    public function registrations(): HasMany
    {
        return $this->hasMany(Registration::class);
    }

    public function eventParticipants(): HasMany
    {
        return $this->hasMany(EventParticipant::class);
    }

    public function winners(): HasMany
    {
        return $this->hasMany(Winner::class);
    }

    // ── Scopes ─────────────────────────────────────────────────────

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /**
     * BUG FIX: Scope ini menggunakan coach_id yang sebelumnya
     * di-comment-out dari $fillable. Sekarang coach_id sudah diaktifkan.
     */
    public function scopeByCoach($query, int $coachId)
    {
        return $query->where('coach_id', $coachId);
    }

    public function scopeByPerguruan($query, int $perguruanId)
    {
        return $query->where('perguruan_id', $perguruanId);
    }

    // ── Accessors ──────────────────────────────────────────────────

    public function getPhotoUrlAttribute(): string
    {
        return $this->photo
            ? asset('storage/' . $this->photo)
            : asset('images/default-avatar.png');
    }

    public function getAgeAttribute(): int
    {
        return $this->birth_date->age;
    }

    public function getGenderLabelAttribute(): string
    {
        return $this->gender === 'male' ? 'Laki-laki' : 'Perempuan';
    }
}

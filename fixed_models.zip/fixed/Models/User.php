<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Builder;
use Spatie\Permission\Traits\HasRoles;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes, HasRoles;

    protected $guard_name = 'web';

    // ── Fillable ───────────────────────────────────────────────────
    protected $fillable = [
        'name',
        'email',
        'password',
        'phone',
        'avatar',
        'status',
        'perguruan_id',
    ];

    // ── Hidden ─────────────────────────────────────────────────────
    protected $hidden = [
        'password',
        'remember_token',
    ];

    // ── Casts ──────────────────────────────────────────────────────
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password'          => 'hashed',
        ];
    }

    // ── Relationships ──────────────────────────────────────────────

    public function perguruan(): BelongsTo
    {
        return $this->belongsTo(Perguruan::class);
    }

    /**
     * Atlet yang di-coach oleh user ini.
     * Kolom: athletes.coach_id (pastikan ada di migration).
     */
    public function athletes(): HasMany
    {
        return $this->hasMany(Athlete::class, 'coach_id');
    }

    /**
     * Skor Taolu yang diinput oleh user ini sebagai operator/judge.
     *
     * BUG FIX: relasi sebelumnya ke Score::class (tidak ada).
     * Diganti ke TaoluScore via kolom inputted_by.
     * Jika ada model ContestScore untuk sparring, tambahkan juga:
     *   public function contestScores(): HasMany { ... }
     */
    public function taoluScores(): HasMany
    {
        return $this->hasMany(TaoluScore::class, 'inputted_by');
    }

    public function createdEvents(): HasMany
    {
        return $this->hasMany(Event::class, 'created_by');
    }

    public function registeredParticipants(): HasMany
    {
        return $this->hasMany(EventParticipant::class, 'registered_by');
    }

    /**
     * BUG FIX: recordedResults sebelumnya ke ContestResult::class
     * dengan nama class yang salah (bertabrakan dengan TaoluScore).
     * Sekarang ContestResult sudah diperbaiki dengan class yang benar.
     */
    public function recordedResults(): HasMany
    {
        return $this->hasMany(ContestResult::class, 'recorded_by');
    }

    public function issuedCertificates(): HasMany
    {
        return $this->hasMany(Certificate::class, 'issued_by');
    }

    // ── Scopes ─────────────────────────────────────────────────────

    public function scopePending(Builder $query): Builder
    {
        return $query->where('status', 'pending');
    }

    public function scopeActive(Builder $query): Builder
    {
        return $query->where('status', 'active');
    }

    public function scopeInactive(Builder $query): Builder
    {
        return $query->where('status', 'inactive');
    }

    // ── Helpers ────────────────────────────────────────────────────

    public function isAdmin(): bool
    {
        return $this->hasRole('admin');
    }

    public function isCoach(): bool
    {
        return $this->hasRole('coach');
    }

    public function isJudge(): bool
    {
        return $this->hasRole('judge');
    }

    public function isAthlete(): bool
    {
        return $this->hasRole('athlete');
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }

    public function getStatusClassAttribute(): string
    {
        return match ($this->status) {
            'pending'  => 'bg-yellow-100 text-yellow-800',
            'active'   => 'bg-green-100 text-green-800',
            'rejected' => 'bg-red-100 text-red-800',
            default    => 'bg-gray-100 text-gray-800',
        };
    }
}

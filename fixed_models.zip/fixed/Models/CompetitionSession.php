<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Carbon\Carbon;

/**
 * Sesi kompetisi — mengelompokkan contest berdasarkan arena, waktu, dan kategori.
 *
 * FIX (CRLF): File dikonversi dari Windows CRLF ke Unix LF.
 * FIX (Design): $fillable dan $casts dipindahkan ke atas sesuai konvensi project.
 */
class CompetitionSession extends Model
{
    // ── Properties ─────────────────────────────────────────────────
    protected $fillable = [
        'event_category_id',
        'gender',
        'arena_id',
        'start_time',
        'duration_per_athlete',
        'notes',
        'status',
    ];

    protected $casts = [
        'start_time'            => 'datetime',
        'duration_per_athlete'  => 'integer',
    ];

    // ── Relationships ──────────────────────────────────────────────

    public function arena(): BelongsTo
    {
        return $this->belongsTo(Arena::class);
    }

    public function eventCategory(): BelongsTo
    {
        return $this->belongsTo(EventCategory::class);
    }

    public function contests(): HasMany
    {
        return $this->hasMany(Contest::class, 'competition_session_id')
            ->orderBy('appearance_order');
    }

    // ── Business Logic ─────────────────────────────────────────────

    /**
     * Hitung estimasi waktu selesai sesi.
     */
    public function estimatedEndTime(): Carbon
    {
        $totalMinutes = $this->contests->count() * $this->duration_per_athlete;

        return $this->start_time->copy()->addMinutes($totalMinutes);
    }

    /**
     * Hitung estimasi waktu tampil per atlet berdasarkan urutan.
     */
    public function estimatedTimeForOrder(int $order): Carbon
    {
        $offset = ($order - 1) * $this->duration_per_athlete;

        return $this->start_time->copy()->addMinutes($offset);
    }

    /**
     * Total durasi sesi dalam menit.
     */
    public function totalDurationMinutes(): int
    {
        return $this->contests->count() * $this->duration_per_athlete;
    }
}

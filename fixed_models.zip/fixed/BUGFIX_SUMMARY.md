# Bug Fix Summary — Models.zip

Semua file yang diubah ada di folder `Models/` dan `database/migrations/`.

---

## 🔴 CRITICAL — Fatal PHP Error / Silent Data Loss

### 1. `ContestResult.php` — Duplikat class `TaoluScore` (Fatal Error)

**Masalah:** File `ContestResult.php` mendefinisikan `class TaoluScore`, sama persis dengan `TaoluScore.php`. PHP akan throw `Cannot redeclare class TaoluScore` saat autoload keduanya.

**Fix:** Class di `ContestResult.php` direname menjadi `ContestResult` (sesuai nama file). Properti disesuaikan dengan peran model ini (hasil akhir contest, bukan skor juri).

---

### 2. `User.php` — Relasi ke class yang tidak ada (`Score`, `ContestResult` lama)

**Masalah:**
- `scores()` → `Score::class` tidak ada di project → fatal `TargetClassDoesNotExist` saat relasi dipanggil.
- `recordedResults()` → `ContestResult::class` merujuk class yang isinya `TaoluScore` (bug #1 di atas).

**Fix:**
- `scores()` diganti menjadi `taoluScores()` → `TaoluScore::class, 'inputted_by'`.
- `recordedResults()` tetap ada, kini bekerja karena `ContestResult` sudah diperbaiki (bug #1).

---

### 3. `Winner.php` — `$fillable` tidak sinkron dengan relasi (Semua relasi null)

**Masalah:** `$fillable` hanya berisi `event_category_id`, tapi relasi aktif `event()`, `discipline()`, `ageCategory()` menggunakan kolom `event_id`, `discipline_id`, `age_category_id` yang tidak ada di tabel → silently return `null`.

**Fix:**
- Relasi `event()`, `discipline()`, `ageCategory()` sebagai `BelongsTo` dihapus.
- Diganti accessor `getEventAttribute()`, `getDisciplineAttribute()`, `getAgeCategoryAttribute()` yang mengambil data via `$this->eventCategory?->event`, dll. (tidak butuh kolom ekstra).
- Scope `scopeForEvent()` dan `scopeForDiscipline()` diperbaiki ke `whereHas('eventCategory', ...)`.
- **Migration disertakan** untuk drop kolom redundan jika masih ada di DB.

---

### 4. `EventCategory.php` — `contests()` pakai join key salah (Over-fetch data)

**Masalah:**
```php
// SEBELUM — mengambil SEMUA contest dalam 1 disiplin, bukan milik kategori ini
return $this->hasMany(Contest::class, 'discipline_id', 'discipline_id');
```

**Fix:**
```php
// SESUDAH — hanya contest milik event_category ini
return $this->hasMany(Contest::class, 'event_category_id');
```

---

### 5. `TaoluScore.php` — Referensi `Contest::STATUS_DONE` tidak ada

**Masalah:** `saveWithFinalScore()` memanggil `Contest::STATUS_DONE` tapi `Contest` tidak mendefinisikan konstanta tersebut → fatal `Undefined constant`.

**Fix:** Konstanta `STATUS_DONE = 'done'` ditambahkan ke **dua tempat**:
- `TaoluScore.php` → `self::STATUS_DONE` (jangka pendek, langsung kerja).
- `Contest.php` → `Contest::STATUS_DONE` + konstanta status lainnya (best practice).

---

## 🟡 WARNING — Bug Nyata, Tidak Langsung Fatal

### 6. `Athlete.php` — `coach()` dan `scopeByCoach()` gunakan kolom yang di-comment-out

**Masalah:** `coach_id` di-comment-out dari `$fillable`. Kolom kemungkinan tidak ada di DB. Relasi selalu null, scope throw SQL error.

**Fix:** `coach_id` diaktifkan di `$fillable`. **Migration disertakan** untuk menambah kolom `coach_id` ke tabel `athletes` jika belum ada.

---

### 7. `Contest.php` — `estimatedTime()` pakai `$this->order_number` (kolom tidak ada)

**Masalah:** Method `estimatedTime()` menggunakan `$this->order_number`, tapi kolom di `$fillable` adalah `appearance_order`.

**Fix:** Diganti ke `$this->appearance_order`.

---

### 8. `Registration.php` — `ageCategory()` pakai `HasMany` (seharusnya `BelongsTo`)

**Masalah:**
```php
public function age_category(): HasMany
{
    return $this->HasMany(AgeCategory::class); // SALAH — tipe relasi terbalik
}
```
Satu registrasi punya satu `age_category_id` → seharusnya `BelongsTo`.

**Fix:** Diganti ke `BelongsTo`, nama method diubah ke `ageCategory()` (konvensi Laravel).

---

### 9. `Event.php` — `use App\Models\Match as Contest` dan `getHasMatchesAttribute()`

**Masalah:**
- `Match` sudah tidak ada (direname ke `Contest`), alias ini menyebabkan class-not-found.
- `getHasMatchesAttribute()` memanggil `$this->matches()` yang tidak ada.

**Fix:**
- Import `Match as Contest` dihapus.
- Ditambah method `contests()` via `hasManyThrough(Contest::class, EventCategory::class)`.
- `getHasMatchesAttribute()` diganti ke `$this->contests()->exists()`.

---

## 🔵 DESIGN — Tidak Fatal, Perlu Ditangani Segera

### 10. `CompetitionSession.php` & `TaoluScore.php` — Windows CRLF line endings

**Fix:** Kedua file dikonversi ke Unix LF. Tambahkan `.gitattributes`:
```
* text=auto eol=lf
*.php text eol=lf
```

### 11. `CompetitionSession.php` — `$fillable` tidak diindentasi, `$casts` di bawah method

**Fix:** Dipindahkan ke atas bersama properti lain, sesuai konvensi semua model lain.

### 12. `Match.php.bak` — File backup di source control

**Fix:** Hapus file dan tambahkan ke `.gitignore`:
```
*.bak
```

### 13. Dua scoring system paralel (`TaoluScore` vs `ContestScore`)

**Rekomendasi:** Dokumentasikan perbedaannya secara eksplisit:
- `TaoluScore` → untuk cabang **performance/Taolu**: 5 juri, trimmed-mean, satu baris per contest.
- `ContestScore` → untuk cabang **sparring**: skor per juri per ronde, satu baris per judge-per-contest.

Tambahkan `$contest->score_type` atau pastikan `EventCategory::format` menentukan model mana yang dipakai.

---

## File yang Diubah

| File | Jenis Fix |
|---|---|
| `Models/ContestResult.php` | 🔴 Critical — rename class |
| `Models/TaoluScore.php` | 🔴 Critical + 🟡 Warning + 🔵 Design |
| `Models/User.php` | 🔴 Critical — relasi phantom |
| `Models/Winner.php` | 🔴 Critical — fillable vs relasi |
| `Models/EventCategory.php` | 🔴 Critical — join key salah |
| `Models/Athlete.php` | 🟡 Warning — coach_id |
| `Models/Contest.php` | 🟡 Warning — STATUS_DONE + order_number |
| `Models/Event.php` | 🟡 Warning — Match alias + matches() |
| `Models/Registration.php` | 🟡 Warning — HasMany vs BelongsTo |
| `Models/CompetitionSession.php` | 🔵 Design — CRLF + formatting |
| `database/migrations/..._fix_winners_schema.php` | Migration pendukung |
| `database/migrations/..._add_coach_id_to_athletes.php` | Migration pendukung |
| `database/migrations/..._ensure_contest_results_table.php` | Migration pendukung |

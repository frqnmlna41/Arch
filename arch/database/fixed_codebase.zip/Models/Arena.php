<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;

class Arena extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'location',
        'capacity',
        'notes',
        'is_active',
    ];

    protected $casts = [
        'capacity'  => 'integer',
        'is_active' => 'boolean',
    ];

    // ─── Relationships ─────────────────────────────────────────

    /**
     * Sesi pertandingan di arena ini.
     */
    public function sessions(): HasMany
    {
        return $this->hasMany(CompetitionSession::class);
    }

    /**
     * Semua contest di arena ini via CompetitionSession.
     * FIXED: matches() lama salah arah (Contest tidak punya arena_id langsung).
     */
    public function contests(): HasManyThrough
    {
        return $this->hasManyThrough(
            Contest::class,
            CompetitionSession::class,
            'arena_id',               // FK di competition_sessions
            'competition_session_id', // FK di contests
        );
    }

    public function eventCategories(): HasMany
    {
        return $this->hasMany(EventCategory::class);
    }

    // ─── Scopes ────────────────────────────────────────────────

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }
}

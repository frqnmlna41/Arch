<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class InvoiceItem extends Model
{
    use HasFactory;

    protected $fillable = [
        'invoice_id',
        'athlete_id',
        'event_participant_id',  // FK ke event_participants (sesuai migration)
        'discipline_id',
        'price',
    ];

    protected $casts = [
        'price' => 'decimal:2',
    ];

    // ─── Relationships ─────────────────────────────────────────

    public function invoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class);
    }

    public function athlete(): BelongsTo
    {
        return $this->belongsTo(Athlete::class);
    }

    public function eventParticipant(): BelongsTo
    {
        return $this->belongsTo(EventParticipant::class);
    }

    public function discipline(): BelongsTo
    {
        return $this->belongsTo(Discipline::class);
    }

    // ─── Accessors ─────────────────────────────────────────────

    /**
     * Shortcut ke EventCategory via EventParticipant.
     * FIXED: dulu langsung ke event_category_id yang tidak ada di tabel ini.
     */
    public function getEventCategoryAttribute(): ?EventCategory
    {
        return $this->eventParticipant?->eventCategory;
    }

    public function getEventAttribute(): ?Event
    {
        return $this->eventParticipant?->eventCategory?->event;
    }

    public function getLabelAttribute(): string
    {
        $name     = $this->athlete?->name ?? 'Atlet';
        $catLabel = $this->eventParticipant?->eventCategory?->getLabel() ?? '-';

        return "{$name} — {$catLabel}";
    }
}

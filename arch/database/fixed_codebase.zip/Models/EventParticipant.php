<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class EventParticipant extends Model
{
    use HasFactory;

    protected $table = 'event_participants';

    protected $fillable = [
        'event_category_id',
        'athlete_id',
        'registration_id',
        'registered_by',
        'verified_by',
        'registration_number',
        'status',
        'weight_at_registration',
        'verified_at',
        'rejection_reason',
    ];

    protected $casts = [
        'verified_at' => 'datetime',
    ];

    const STATUS_PENDING      = 'pending';
    const STATUS_VERIFIED     = 'verified';
    const STATUS_REJECTED     = 'rejected';
    const STATUS_WITHDRAWN    = 'withdrawn';
    const STATUS_DISQUALIFIED = 'disqualified';

    // ─── Relationships ─────────────────────────────────────────

    public function eventCategory(): BelongsTo
    {
        return $this->belongsTo(EventCategory::class);
    }

    public function athlete(): BelongsTo
    {
        return $this->belongsTo(Athlete::class);
    }

    public function registration(): BelongsTo
    {
        return $this->belongsTo(Registration::class);
    }

    public function registeredBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'registered_by');
    }

    public function verifiedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'verified_by');
    }

    public function contest(): HasOne
    {
        return $this->hasOne(Contest::class, 'registration_id', 'registration_id');
    }

    // ─── Accessors (shortcut via eventCategory) ────────────────

    /**
     * Ambil event via eventCategory — tidak butuh kolom event_id di tabel ini.
     */
    public function getEventAttribute(): ?Event
    {
        return $this->eventCategory?->event;
    }

    public function getDisciplineAttribute(): ?Discipline
    {
        return $this->eventCategory?->discipline;
    }

    public function getAgeCategoryAttribute(): ?AgeCategory
    {
        return $this->eventCategory?->ageCategory;
    }

    // ─── Scopes ────────────────────────────────────────────────

    public function scopeVerified($query)
    {
        return $query->where('status', self::STATUS_VERIFIED);
    }

    public function scopePending($query)
    {
        return $query->where('status', self::STATUS_PENDING);
    }

    // ─── Helpers ───────────────────────────────────────────────

    public function isVerified(): bool
    {
        return $this->status === self::STATUS_VERIFIED;
    }

    public function verify(User $admin): self
    {
        $this->update([
            'status'      => self::STATUS_VERIFIED,
            'verified_by' => $admin->id,
            'verified_at' => now(),
        ]);

        return $this;
    }

    public function reject(string $reason): self
    {
        $this->update([
            'status'           => self::STATUS_REJECTED,
            'rejection_reason' => $reason,
        ]);

        return $this;
    }

    /**
     * Generate nomor pendaftaran aman dari race condition.
     * Format: WU-2024-0001
     * Gunakan di dalam DB::transaction dengan lockForUpdate.
     */
    public static function generateNumber(): string
    {
        $prefix = 'WU-' . now()->year . '-';
        $last   = self::where('registration_number', 'like', $prefix . '%')
                      ->orderByDesc('registration_number')
                      ->lockForUpdate()
                      ->value('registration_number');

        $sequence = $last ? ((int) substr($last, -4)) + 1 : 1;

        return $prefix . str_pad($sequence, 4, '0', STR_PAD_LEFT);
    }
}

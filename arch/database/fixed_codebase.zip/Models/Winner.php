<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Winner extends Model
{
    use HasFactory;

    protected $table = 'winners';

    protected $fillable = [
        'event_category_id',
        'athlete_id',
        'rank',
        'total_score',
        'medal_type',
        'notes',
    ];

    protected $casts = [
        'rank'        => 'integer',
        'total_score' => 'decimal:3',
    ];

    const MEDAL_GOLD   = 'gold';
    const MEDAL_SILVER = 'silver';
    const MEDAL_BRONZE = 'bronze';

    // ─── Relationships ─────────────────────────────────────────

    public function eventCategory(): BelongsTo
    {
        return $this->belongsTo(EventCategory::class);
    }

    public function athlete(): BelongsTo
    {
        return $this->belongsTo(Athlete::class);
    }

    public function certificate(): HasOne
    {
        return $this->hasOne(Certificate::class);
    }

    // ─── Accessors (shortcut via eventCategory) ────────────────

    public function getEventAttribute(): ?Event
    {
        return $this->eventCategory?->event;
    }

    public function getDisciplineAttribute(): ?Discipline
    {
        return $this->eventCategory?->discipline;
    }

    public function getAgeCategoryAttribute(): ?AgeCategory
    {
        return $this->eventCategory?->ageCategory;
    }

    // ─── Scopes ────────────────────────────────────────────────

    public function scopeGold($query)
    {
        return $query->where('rank', 1);
    }

    public function scopeSilver($query)
    {
        return $query->where('rank', 2);
    }

    public function scopeBronze($query)
    {
        return $query->where('rank', 3);
    }

    public function scopeForEvent($query, int $eventId)
    {
        return $query->whereHas('eventCategory', fn ($q) => $q->where('event_id', $eventId));
    }

    public function scopeForDiscipline($query, int $disciplineId)
    {
        return $query->whereHas('eventCategory', fn ($q) => $q->where('discipline_id', $disciplineId));
    }

    // ─── Helpers ───────────────────────────────────────────────

    public function getMedalLabelAttribute(): string
    {
        return match ($this->rank) {
            1 => 'Juara 1 (Emas)',
            2 => 'Juara 2 (Perak)',
            3 => 'Juara 3 (Perunggu)',
            default => "Juara {$this->rank}",
        };
    }

    public function isGold(): bool   { return $this->rank === 1; }
    public function isSilver(): bool { return $this->rank === 2; }
    public function isBronze(): bool { return $this->rank === 3; }

    public function hasCertificate(): bool
    {
        return $this->certificate()->exists();
    }
}

<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class CompetitionSession extends Model
{
    const STATUS_DRAFT   = 'draft';
    const STATUS_ONGOING = 'ongoing';
    const STATUS_DONE    = 'done';

    protected $fillable = [
        'event_category_id',
        'gender',
        'arena_id',
        'start_time',
        'duration_per_athlete',
        'notes',
        'status',
    ];

    protected $casts = [
        'start_time'           => 'datetime',
        'duration_per_athlete' => 'integer',
    ];

    // ─── Relationships ─────────────────────────────────────────

    public function arena(): BelongsTo
    {
        return $this->belongsTo(Arena::class);
    }

    public function eventCategory(): BelongsTo
    {
        return $this->belongsTo(EventCategory::class);
    }

    public function contests(): HasMany
    {
        return $this->hasMany(Contest::class, 'competition_session_id')
                    ->orderBy('appearance_order');
    }

    // ─── Business logic ────────────────────────────────────────

    /**
     * Hitung estimasi waktu selesai sesi.
     * FIXED: gunakan query count() bukan $this->contests->count()
     * untuk menghindari N+1 ketika dipanggil dalam loop.
     */
    public function estimatedEndTime(): Carbon
    {
        $total = $this->contests()->count() * $this->duration_per_athlete;

        return $this->start_time->copy()->addMinutes($total);
    }

    /**
     * Hitung estimasi waktu tampil per nomor urut.
     */
    public function estimatedTimeForOrder(int $order): Carbon
    {
        $offset = ($order - 1) * $this->duration_per_athlete;

        return $this->start_time->copy()->addMinutes($offset);
    }

    /**
     * Total durasi sesi dalam menit.
     * FIXED: gunakan query count() untuk menghindari N+1.
     */
    public function totalDurationMinutes(): int
    {
        return $this->contests()->count() * $this->duration_per_athlete;
    }
}

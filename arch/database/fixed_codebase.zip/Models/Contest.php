<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Contest extends Model
{
    const STATUS_SCHEDULED = 'scheduled';
    const STATUS_ONGOING   = 'ongoing';
    const STATUS_DONE      = 'done';
    const STATUS_CANCELLED = 'cancelled';

    protected $fillable = [
        'event_category_id',
        'athlete_id',
        'registration_id',
        'discipline_id',
        'age_category_id',
        'competition_session_id',
        'appearance_order',
        'status',
    ];

    protected $casts = [
        'appearance_order' => 'integer',
    ];

    public function eventCategory(): BelongsTo
    {
        return $this->belongsTo(EventCategory::class);
    }

    public function athlete(): BelongsTo
    {
        return $this->belongsTo(Athlete::class);
    }

    public function registration(): BelongsTo
    {
        return $this->belongsTo(Registration::class);
    }

    public function discipline(): BelongsTo
    {
        return $this->belongsTo(Discipline::class);
    }

    public function ageCategory(): BelongsTo
    {
        return $this->belongsTo(AgeCategory::class);
    }

    public function session(): BelongsTo
    {
        return $this->belongsTo(CompetitionSession::class, 'competition_session_id');
    }

    public function score(): HasOne
    {
        return $this->hasOne(TaoluScore::class);
    }

    public function estimatedTime(): ?Carbon
    {
        if (! $this->session || ! $this->appearance_order) {
            return null;
        }

        return $this->session->estimatedTimeForOrder($this->appearance_order);
    }

    public function isScored(): bool
    {
        return $this->score !== null && $this->score->final_score !== null;
    }
}

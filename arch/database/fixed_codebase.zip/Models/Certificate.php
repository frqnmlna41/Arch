<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Certificate extends Model
{
    use HasFactory;

    protected $table = 'certificates';

    protected $fillable = [
        'winner_id',
        'issued_by',
        'certificate_number',
        'file_path',
        'issued_at',
        'is_printed',
        'printed_at',
        'template_version',
        'notes',
    ];

    protected $casts = [
        'issued_at'  => 'datetime',
        'printed_at' => 'datetime',
        'is_printed' => 'boolean',
    ];

    // ─── Relationships ─────────────────────────────────────────

    public function winner(): BelongsTo
    {
        return $this->belongsTo(Winner::class);
    }

    public function issuedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'issued_by');
    }

    // ─── Accessors (shortcut via winner) ───────────────────────

    public function getAthleteAttribute(): ?Athlete
    {
        return $this->winner?->athlete;
    }

    public function getEventAttribute(): ?Event
    {
        return $this->winner?->event;
    }

    // ─── Scopes ────────────────────────────────────────────────

    public function scopeIssued($query)
    {
        return $query->whereNotNull('issued_at');
    }

    public function scopePrinted($query)
    {
        return $query->where('is_printed', true);
    }

    public function scopeNotPrinted($query)
    {
        return $query->where('is_printed', false);
    }

    // ─── Helpers ───────────────────────────────────────────────

    public function isIssued(): bool  { return ! is_null($this->issued_at); }
    public function isPrinted(): bool { return $this->is_printed; }
    public function hasFile(): bool   { return ! is_null($this->file_path); }

    /**
     * Generate nomor sertifikat unik — aman dari race condition.
     * FIXED: gunakan orderByDesc bukan count()+1 agar tidak duplikat.
     * Kolom certificate_number wajib punya UNIQUE constraint di DB.
     * Format: CERT-YYYY-NNNNN
     */
    public static function generateNumber(): string
    {
        $prefix = 'CERT-' . now()->year . '-';
        $last   = static::where('certificate_number', 'like', $prefix . '%')
                        ->orderByDesc('certificate_number')
                        ->lockForUpdate()
                        ->value('certificate_number');

        $sequence = $last ? ((int) substr($last, -5)) + 1 : 1;

        return $prefix . str_pad($sequence, 5, '0', STR_PAD_LEFT);
    }
}

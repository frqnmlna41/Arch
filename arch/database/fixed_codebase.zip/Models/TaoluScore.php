<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TaoluScore extends Model
{
    protected $fillable = [
        'contest_id',
        'judge_1', 'judge_2', 'judge_3', 'judge_4', 'judge_5',
        'deduction',
        'final_score',
        'inputted_by',
        'inputted_at',
    ];

    protected $casts = [
        'inputted_at' => 'datetime',
        'judge_1'     => 'float',
        'judge_2'     => 'float',
        'judge_3'     => 'float',
        'judge_4'     => 'float',
        'judge_5'     => 'float',
        'deduction'   => 'float',
        'final_score' => 'float',
    ];

    // ─── Relationships ─────────────────────────────────────────

    public function contest(): BelongsTo
    {
        return $this->belongsTo(Contest::class);
    }

    public function inputter(): BelongsTo
    {
        return $this->belongsTo(User::class, 'inputted_by');
    }

    // ─── Business logic ────────────────────────────────────────

    /**
     * Hitung final score Taolu:
     * Buang nilai tertinggi & terendah dari 5 juri,
     * jumlahkan 3 sisanya, kurangi deduction.
     */
    public function calculateFinalScore(): float
    {
        $scores = collect([
            $this->judge_1,
            $this->judge_2,
            $this->judge_3,
            $this->judge_4,
            $this->judge_5,
        ])->filter()->sort()->values();

        if ($scores->count() < 3) {
            return 0;
        }

        $trimmed = $scores->slice(1, $scores->count() - 2);

        return round($trimmed->sum() - ($this->deduction ?? 0), 3);
    }

    /**
     * Simpan skor dan update final_score + status contest secara atomik.
     * FIXED: Contest::STATUS_DONE sekarang ada sebagai konstanta di Contest.
     */
    public function saveWithFinalScore(): void
    {
        $this->final_score = $this->calculateFinalScore();
        $this->inputted_at = now();
        $this->inputted_by = auth()->id();
        $this->save();

        $this->contest->update(['status' => Contest::STATUS_DONE]);
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Builder;
use Spatie\Permission\Traits\HasRoles;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes, HasRoles;

    protected $guard_name = 'web';

    protected $fillable = [
        'name',
        'email',
        'password',
        'phone',
        'avatar',
        'status',
        'perguruan_id',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password'          => 'hashed',
        ];
    }

    // ─── Relationships ─────────────────────────────────────────

    public function perguruan(): BelongsTo
    {
        return $this->belongsTo(Perguruan::class);
    }

    /**
     * Atlet yang dicoach oleh user ini.
     */
    public function athletes(): HasMany
    {
        return $this->hasMany(Athlete::class, 'coach_id');
    }

    /**
     * Nilai Taolu yang diinput oleh user ini (sebagai operator).
     */
    public function taoluScores(): HasMany
    {
        return $this->hasMany(TaoluScore::class, 'inputted_by');
    }

    /**
     * Nilai ContestScore yang diberikan oleh user ini (sebagai juri).
     */
    public function judgeScores(): HasMany
    {
        return $this->hasMany(ContestScore::class, 'judge_id');
    }

    public function createdEvents(): HasMany
    {
        return $this->hasMany(Event::class, 'created_by');
    }

    public function registeredParticipants(): HasMany
    {
        return $this->hasMany(EventParticipant::class, 'registered_by');
    }

    public function issuedCertificates(): HasMany
    {
        return $this->hasMany(Certificate::class, 'issued_by');
    }

    public function invoices(): HasMany
    {
        return $this->hasMany(Invoice::class);
    }

    // ─── Scopes ────────────────────────────────────────────────

    public function scopePending(Builder $query): Builder
    {
        return $query->where('status', 'pending');
    }

    public function scopeActive(Builder $query): Builder
    {
        return $query->where('status', 'active');
    }

    public function scopeInactive(Builder $query): Builder
    {
        return $query->where('status', 'inactive');
    }

    // ─── Helpers ───────────────────────────────────────────────

    public function isAdmin(): bool    { return $this->hasRole('admin'); }
    public function isCoach(): bool    { return $this->hasRole('coach'); }
    public function isJudge(): bool    { return $this->hasRole('judge'); }
    public function isAthlete(): bool  { return $this->hasRole('athlete'); }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }

    public function getStatusClassAttribute(): string
    {
        return match ($this->status) {
            'pending'  => 'bg-yellow-100 text-yellow-800',
            'active'   => 'bg-green-100 text-green-800',
            'rejected' => 'bg-red-100 text-red-800',
            default    => 'bg-gray-100 text-gray-800',
        };
    }
}

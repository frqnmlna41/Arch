<?php

namespace App\Services;

use App\Models\AgeCategory;
use App\Models\Athlete;
use App\Models\CompetitionSession;
use App\Models\Contest;
use App\Models\Discipline;
use App\Models\Event;
use App\Models\EventCategory;
use App\Models\EventParticipant;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\Registration;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class RegistrationService
{
    const PRICE_PER_DISCIPLINE = 200000;

    /**
     * Daftarkan satu atlet ke satu atau lebih disiplin dalam satu transaksi.
     *
     * Untuk setiap disiplin:
     *   1. EventCategory  — pastikan kategori (disiplin+age+gender) ada dalam event
     *   2. Registration   — catat pendaftaran per disiplin
     *   3. CompetitionSession — siapkan sesi (dibuat oleh admin, di sini hanya firstOrCreate placeholder)
     *   4. EventParticipant  — catat atlet sebagai peserta resmi
     *   5. Contest           — buat slot tanding dengan nomor urut aman
     *   6. InvoiceItem       — tagih per disiplin ke invoice coach
     *
     * @param  Athlete  $athlete
     * @param  array    $disciplines  [['discipline_id' => int, 'age_category_id' => int], ...]
     * @param  int|null $eventId      ID event target; null = ambil event published pertama
     * @throws \RuntimeException jika tidak ada event aktif
     */
    public function registerDisciplines(Athlete $athlete, array $disciplines, ?int $eventId = null): Invoice
    {
        return DB::transaction(function () use ($athlete, $disciplines, $eventId) {

            // ── Resolve event aktif ──────────────────────────────────────
            // Lebih baik event ID dikirim eksplisit dari controller/form.
            // Fallback ke published pertama untuk backward-compatibility.
            $event = $eventId
                ? Event::findOrFail($eventId)
                : Event::where('status', Event::STATUS_PUBLISHED)
                       ->where('registration_start', '<=', now())
                       ->where('registration_end', '>=', now())
                       ->firstOrFail();

            // ── Invoice draft milik coach ini ────────────────────────────
            $invoice   = $this->getOrCreateInvoice();
            $pivotData = [];

            foreach ($disciplines as $item) {
                $disciplineId  = (int) $item['discipline_id'];
                $ageCategoryId = (int) $item['age_category_id'];

                $discipline  = Discipline::findOrFail($disciplineId);
                $ageCategory = AgeCategory::findOrFail($ageCategoryId);

                // ── 1. EventCategory ─────────────────────────────────────
                $eventCategory = EventCategory::firstOrCreate(
                    [
                        'event_id'        => $event->id,
                        'sport_id'        => $discipline->sport_id,
                        'gender'          => $athlete->gender,
                        'discipline_id'   => $disciplineId,
                        'age_category_id' => $ageCategoryId,
                    ],
                    [
                        'format' => EventCategory::FORMAT_SCORING,
                    ]
                );

                // ── 2. Registration ──────────────────────────────────────
                $registration = Registration::firstOrCreate(
                    [
                        'athlete_id'        => $athlete->id,
                        'event_category_id' => $eventCategory->id,
                        'discipline_id'     => $disciplineId,
                        'age_category_id'   => $ageCategoryId,
                    ],
                    [
                        'user_id'       => Auth::id(),
                        'status'        => Registration::STATUS_PENDING,
                        'registered_at' => now(),
                    ]
                );

                // ── 3. CompetitionSession (placeholder — diatur admin) ───
                // FIXED: kirim arena_id (null) bukan field 'lapangan' yang tidak ada.
                $session = CompetitionSession::firstOrCreate(
                    [
                        'event_category_id' => $eventCategory->id,
                        'gender'            => $athlete->gender,
                    ],
                    [
                        'arena_id'             => null,
                        'start_time'           => now()->startOfDay()->addHours(8),
                        'duration_per_athlete' => 4,
                        'status'               => CompetitionSession::STATUS_DRAFT,
                        'notes'                => 'Belum diatur — harap lengkapi via admin.',
                    ]
                );

                // ── 4. EventParticipant ──────────────────────────────────
                $eventParticipant = EventParticipant::firstOrCreate(
                    [
                        'registration_id' => $registration->id,
                        'athlete_id'      => $athlete->id,
                    ],
                    [
                        'event_category_id'   => $eventCategory->id,
                        'registration_number' => EventParticipant::generateNumber(),
                        'registered_by'       => Auth::id(),
                        'status'              => EventParticipant::STATUS_PENDING,
                    ]
                );

                // ── 5. Contest dengan appearance_order aman ──────────────
                // FIXED: lockForUpdate mencegah race condition nomor urut duplikat.
                $nextOrder = Contest::where('competition_session_id', $session->id)
                    ->lockForUpdate()
                    ->max('appearance_order');

                $nextOrder = $nextOrder ? $nextOrder + 1 : 1;

                Contest::firstOrCreate(
                    ['registration_id' => $registration->id],
                    [
                        'event_category_id'      => $eventCategory->id,
                        'competition_session_id' => $session->id,
                        'athlete_id'             => $athlete->id,
                        'discipline_id'          => $disciplineId,
                        'age_category_id'        => $ageCategoryId,
                        'appearance_order'       => $nextOrder,
                        'status'                 => Contest::STATUS_SCHEDULED,
                    ]
                );

                // ── 6. InvoiceItem (idempoten) ───────────────────────────
                $alreadyExists = InvoiceItem::where('invoice_id', $invoice->id)
                    ->where('athlete_id', $athlete->id)
                    ->where('event_participant_id', $eventParticipant->id)
                    ->exists();

                if (! $alreadyExists) {
                    InvoiceItem::create([
                        'invoice_id'           => $invoice->id,
                        'athlete_id'           => $athlete->id,
                        'event_participant_id' => $eventParticipant->id,
                        'discipline_id'        => $disciplineId,
                        'price'                => self::PRICE_PER_DISCIPLINE,
                    ]);
                }

                // Kumpulkan pivot untuk sync setelah loop selesai
                $pivotData[$disciplineId] = ['age_category_id' => $ageCategoryId];
            }

            // ── Sync pivot athlete_discipline (tidak hapus yang lama) ────
            $athlete->disciplines()->syncWithoutDetaching($pivotData);

            // ── Hitung ulang total invoice ───────────────────────────────
            $invoice->recalculateTotal();

            return $invoice->fresh('items');
        });
    }

    private function getOrCreateInvoice(): Invoice
    {
        return Invoice::firstOrCreate(
            [
                'user_id' => Auth::id(),
                'status'  => Invoice::STATUS_DRAFT,
            ],
            [
                'invoice_number' => Invoice::generateNumber(),
                'total_amount'   => 0,
            ]
        );
    }

    public function approve(Registration $registration): void
    {
        $registration->update(['status' => Registration::STATUS_APPROVED]);
    }

    public function reject(Registration $registration): void
    {
        $registration->update(['status' => Registration::STATUS_REJECTED]);
    }
}

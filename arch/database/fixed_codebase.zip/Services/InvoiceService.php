<?php

namespace App\Services;

use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\Registration;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class InvoiceService
{
    /**
     * Buat invoice manual untuk satu coach berdasarkan registrasi approved
     * yang belum memiliki invoice item.
     *
     * FIXED: gunakan User bukan Coach (tidak ada model Coach).
     * FIXED: kolom FK adalah user_id bukan coach_id di tabel invoices.
     */
    public function generateForCoach(User $coach): Invoice
    {
        return DB::transaction(function () use ($coach) {

            $registrations = Registration::where('user_id', $coach->id)
                ->where('status', Registration::STATUS_APPROVED)
                ->whereDoesntHave('invoiceItem')
                ->with('discipline', 'eventParticipant')
                ->get();

            if ($registrations->isEmpty()) {
                throw new \RuntimeException('Tidak ada registrasi approved yang bisa dibuatkan invoice.');
            }

            $invoice = Invoice::create([
                'user_id'        => $coach->id,
                'invoice_number' => Invoice::generateNumber(),
                'total_amount'   => 0,
                'status'         => Invoice::STATUS_DRAFT,
                'due_date'       => now()->addDays(7),
            ]);

            foreach ($registrations as $registration) {
                $participant = $registration->eventParticipant;

                if (! $participant) {
                    continue;
                }

                InvoiceItem::create([
                    'invoice_id'           => $invoice->id,
                    'athlete_id'           => $registration->athlete_id,
                    'event_participant_id' => $participant->id,
                    'discipline_id'        => $registration->discipline_id,
                    'price'                => RegistrationService::PRICE_PER_DISCIPLINE,
                ]);
            }

            $invoice->recalculateTotal();

            return $invoice->fresh('items');
        });
    }
}

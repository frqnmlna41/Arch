<?php

namespace Database\Seeders;

use App\Models\AgeCategory;
use App\Models\Athlete;
use App\Models\Discipline;
use App\Models\Event;
use App\Models\User;
use App\Services\RegistrationService;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Auth;

class RegistrationServiceSeeder extends Seeder
{
    /**
     * Seed pendaftaran atlet menggunakan RegistrationService
     * agar semua relasi (Invoice, Contest, EventCategory, dsb)
     * tergenerate dengan benar, identik dengan alur dari coach di production.
     *
     * Jalankan setelah:
     *   EventSeeder, AthleteSeeder, DisciplineSeeder, AgeCategorySeeder
     *
     * php artisan db:seed --class=RegistrationServiceSeeder
     */
    public function run(RegistrationService $registrationService): void
    {
        // ── Guard: pastikan semua data prasyarat tersedia ──────────────

        $event = Event::where('status', 'published')
            ->where('registration_start', '<=', now())
            ->where('registration_end', '>=', now())
            ->first();

        if (! $event) {
            $this->command->error('❌ Tidak ada event yang sedang buka pendaftaran (status=published + rentang tanggal aktif).');
            $this->command->warn('   Jalankan EventSeeder terlebih dahulu, pastikan registration_start <= now <= registration_end.');
            return;
        }

        // FIX: cari coach berdasarkan role, bukan hard-code ID 5
        // agar seeder tidak bergantung pada urutan insert yang bisa berubah.
        $coach = User::role('coach')->first();

        if (! $coach) {
            $this->command->error('❌ Tidak ada user dengan role "coach". Jalankan UserSeeder terlebih dahulu.');
            return;
        }

        $athletes      = Athlete::all();
        $disciplines   = Discipline::all();
        $ageCategories = AgeCategory::all();

        if ($athletes->isEmpty()) {
            $this->command->error('❌ Belum ada Athlete. Jalankan AthleteSeeder terlebih dahulu.');
            return;
        }

        if ($disciplines->isEmpty()) {
            $this->command->error('❌ Belum ada Discipline. Jalankan DisciplineSeeder terlebih dahulu.');
            return;
        }

        if ($ageCategories->isEmpty()) {
            $this->command->error('❌ Belum ada AgeCategory. Jalankan AgeCategorySeeder terlebih dahulu.');
            return;
        }

        // ── Setup ──────────────────────────────────────────────────────

        // Login sebagai coach — RegistrationService butuh Auth::id()
        Auth::login($coach);

        // Ambil maks 10 atlet, pastikan coach_id-nya terset
        $coachAthletes = $athletes->take(10);

        // FIX: update via Eloquent model per item, bukan collection bulk,
        // untuk memastikan event model-nya terpanggil dengan benar.
        foreach ($coachAthletes as $athlete) {
            $athlete->update(['coach_id' => $coach->id]);
        }

        $this->command->info("ℹ️  Event    : {$event->name} (ID {$event->id})");
        $this->command->info("ℹ️  Coach    : {$coach->name} (ID {$coach->id})");
        $this->command->info("ℹ️  Atlet    : {$coachAthletes->count()} orang");

        // ── Loop pendaftaran ───────────────────────────────────────────

        $successCount = 0;
        $skipCount    = 0;
        $errorCount   = 0;

        foreach ($coachAthletes as $athlete) {
            // Pilih 1–2 disiplin acak untuk tiap atlet
            $selectedDisciplines = $disciplines->random(min(2, $disciplines->count()));

            // FIX: setiap disiplin dipasangkan dengan age category
            // yang sesuai dengan usia atlet (jika tersedia);
            // fallback ke random jika belum ada matching logic.
            $items = [];

            foreach ($selectedDisciplines as $discipline) {
                // Idealnya: filter ageCategory berdasarkan birth_date atlet.
                // Untuk seeder, random sudah cukup — validasi bisnis ada di service.
                $ageCategory = $ageCategories->random();

                $items[] = [
                    'discipline_id'   => $discipline->id,
                    'age_category_id' => $ageCategory->id,
                ];
            }

            try {
                // FIX: kirim event_id eksplisit agar service tidak
                // salah ambil event jika ada lebih dari satu published.
                $registrationService->registerDisciplines($athlete, $items, $event->id);
                $successCount++;

                $disciplineNames = $selectedDisciplines->pluck('name')->implode(', ');
                $this->command->line("  ✅ {$athlete->name} → {$disciplineNames}");

            } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
                // Discipline atau AgeCategory tidak ditemukan
                $this->command->warn("  ⚠️  {$athlete->name}: data tidak ditemukan — {$e->getMessage()}");
                $skipCount++;

            } catch (\RuntimeException $e) {
                // Event tidak aktif, atau error bisnis lain dari service
                $this->command->warn("  ⚠️  {$athlete->name}: {$e->getMessage()}");
                $skipCount++;

            } catch (\Throwable $e) {
                // Error tak terduga — tampilkan lengkap untuk debugging
                $this->command->error("  ❌ {$athlete->name}: " . $e->getMessage());

                if ($this->command->getOutput()->isVerbose()) {
                    $this->command->error($e->getTraceAsString());
                }

                $errorCount++;
            }
        }

        // ── Ringkasan ──────────────────────────────────────────────────

        $this->command->newLine();
        $this->command->info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        $this->command->info("✅ Berhasil   : {$successCount} atlet");

        if ($skipCount > 0) {
            $this->command->warn("⚠️  Dilewati   : {$skipCount} atlet (data tidak lengkap)");
        }

        if ($errorCount > 0) {
            $this->command->error("❌ Error      : {$errorCount} atlet (cek log di atas)");
        }

        $this->command->info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

        // Logout setelah selesai — jangan biarkan sesi coach aktif
        Auth::logout();
    }
}

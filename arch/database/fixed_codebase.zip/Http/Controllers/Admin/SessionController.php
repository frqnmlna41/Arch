<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Arena;
use App\Models\CompetitionSession;
use App\Models\Contest;
use App\Models\EventCategory;
use App\Models\Registration;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class SessionController extends Controller
{
    /**
     * Daftar semua sesi.
     */
    public function index(): View
    {
        $sessions = CompetitionSession::with([
                'arena',
                'eventCategory.discipline',
                'eventCategory.ageCategory',
                'contests',
            ])
            ->withCount('contests')
            ->orderBy('start_time')
            ->paginate(20);

        $unsessioned = EventCategory::with(['discipline', 'ageCategory'])
            ->whereDoesntHave('sessions')
            ->get();

        return view('admin.sessions.index', compact('sessions', 'unsessioned'));
    }

    /**
     * Form buat sesi baru.
     */
    public function create(): View
    {
        $eventCategories = EventCategory::with(['discipline', 'ageCategory', 'arena'])->get();
        $arenas          = Arena::active()->orderBy('name')->get();

        return view('admin.sessions.create', compact('eventCategories', 'arenas'));
    }

    /**
     * Simpan sesi baru dan generate slot contest.
     * FIXED: simpan arena_id (bukan lapangan), pakai appearance_order (bukan order_number).
     */
    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'event_category_id'    => ['required', 'exists:event_categories,id'],
            'gender'               => ['required', 'in:male,female,mixed'],
            'arena_id'             => ['required', 'exists:arenas,id'],
            'start_time'           => ['required', 'date'],
            'duration_per_athlete' => ['required', 'integer', 'min:1', 'max:60'],
            'notes'                => ['nullable', 'string'],
        ]);

        $session = CompetitionSession::create([
            'event_category_id'    => $request->event_category_id,
            'gender'               => $request->gender,
            'arena_id'             => $request->arena_id,
            'start_time'           => $request->start_time,
            'duration_per_athlete' => $request->duration_per_athlete,
            'notes'                => $request->notes,
            'status'               => CompetitionSession::STATUS_DRAFT,
        ]);

        $registrations = Registration::where('discipline_id', $session->eventCategory->discipline_id)
            ->where('age_category_id', $session->eventCategory->age_category_id)
            ->where('status', Registration::STATUS_APPROVED)
            ->whereHas('athlete', fn ($q) => $q->where('gender', $session->gender))
            ->get();

        foreach ($registrations as $i => $reg) {
            Contest::firstOrCreate(
                [
                    'event_category_id' => $session->event_category_id,
                    'athlete_id'        => $reg->athlete_id,
                ],
                [
                    'registration_id'        => $reg->id,
                    'competition_session_id' => $session->id,
                    'appearance_order'       => $i + 1,
                    'status'                 => Contest::STATUS_SCHEDULED,
                ]
            );
        }

        return redirect()
            ->route('admin.sessions.show', $session)
            ->with('success', "Sesi berhasil dibuat dengan {$registrations->count()} atlet.");
    }

    /**
     * Detail sesi.
     */
    public function show(CompetitionSession $session): View
    {
        $session->load([
            'arena',
            'eventCategory.discipline',
            'eventCategory.ageCategory',
            'contests.athlete.perguruan',
            'contests.score',
        ]);

        return view('admin.sessions.show', compact('session'));
    }

    /**
     * Form edit sesi.
     */
    public function edit(CompetitionSession $session): View
    {
        $eventCategories = EventCategory::with(['discipline', 'ageCategory'])->get();
        $arenas          = Arena::active()->orderBy('name')->get();

        return view('admin.sessions.edit', compact('session', 'eventCategories', 'arenas'));
    }

    /**
     * Update sesi.
     * FIXED: pakai arena_id bukan lapangan.
     */
    public function update(Request $request, CompetitionSession $session): RedirectResponse
    {
        $request->validate([
            'arena_id'             => ['required', 'exists:arenas,id'],
            'start_time'           => ['required', 'date'],
            'duration_per_athlete' => ['required', 'integer', 'min:1', 'max:60'],
            'notes'                => ['nullable', 'string'],
        ]);

        $session->update($request->only([
            'arena_id', 'start_time', 'duration_per_athlete', 'notes',
        ]));

        return back()->with('success', 'Sesi berhasil diupdate.');
    }

    /**
     * Simpan ulang urutan atlet dalam sesi.
     * FIXED: pakai appearance_order (konsisten dengan migration + Contest model).
     */
    public function updateOrder(Request $request, CompetitionSession $session): RedirectResponse
    {
        $request->validate([
            'contests'                       => ['required', 'array'],
            'contests.*.id'                  => ['required', 'exists:contests,id'],
            'contests.*.appearance_order'    => ['required', 'integer', 'min:1'],
        ]);

        foreach ($request->contests as $data) {
            Contest::where('id', $data['id'])
                ->where('competition_session_id', $session->id)
                ->update(['appearance_order' => $data['appearance_order']]);
        }

        return back()->with('success', 'Urutan atlet berhasil disimpan.');
    }

    /**
     * Generate semua sesi dari seluruh registrasi approved.
     * FIXED: hitungan $contestCount yang selalu 0 diperbaiki.
     */
    public function generateAll(): RedirectResponse
    {
        $groups = Registration::where('status', Registration::STATUS_APPROVED)
            ->with('athlete', 'discipline', 'ageCategory')
            ->get()
            ->groupBy(fn ($r) =>
                $r->discipline_id . '-' .
                $r->age_category_id . '-' .
                $r->athlete->gender
            );

        $sessionCount = 0;
        $contestCount = 0;

        foreach ($groups as $registrations) {
            $first         = $registrations->first();
            $disciplineId  = $first->discipline_id;
            $ageCategoryId = $first->age_category_id;
            $gender        = $first->athlete->gender;

            $eventCategory = EventCategory::firstOrCreate([
                'discipline_id'   => $disciplineId,
                'age_category_id' => $ageCategoryId,
            ]);

            $session = CompetitionSession::firstOrCreate(
                [
                    'event_category_id' => $eventCategory->id,
                    'gender'            => $gender,
                ],
                [
                    'arena_id'             => null,
                    'start_time'           => now()->startOfDay()->addHours(8),
                    'duration_per_athlete' => 4,
                    'status'               => CompetitionSession::STATUS_DRAFT,
                    'notes'                => 'Auto-generated — harap lengkapi arena dan waktu.',
                ]
            );

            $sessionCount++;

            foreach ($registrations as $i => $reg) {
                $created = Contest::firstOrCreate(
                    [
                        'event_category_id' => $eventCategory->id,
                        'athlete_id'        => $reg->athlete_id,
                    ],
                    [
                        'registration_id'        => $reg->id,
                        'competition_session_id' => $session->id,
                        'appearance_order'       => $i + 1,
                        'status'                 => Contest::STATUS_SCHEDULED,
                    ]
                );

                // FIXED: hitung contestCount dengan benar
                if ($created->wasRecentlyCreated) {
                    $contestCount++;
                }
            }
        }

        return redirect()
            ->route('admin.sessions.index')
            ->with('success', "{$sessionCount} sesi berhasil digenerate dengan total {$contestCount} atlet baru.");
    }
}

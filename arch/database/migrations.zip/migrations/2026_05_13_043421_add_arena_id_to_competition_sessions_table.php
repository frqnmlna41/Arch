<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        /*
        |--------------------------------------------------------------------------
        | competition_sessions
        |--------------------------------------------------------------------------
        */

        Schema::table('competition_sessions', function (Blueprint $table) {

            // hapus lapangan lama
            if (Schema::hasColumn('competition_sessions', 'lapangan')) {
                $table->dropColumn('lapangan');
            }

            // tambah arena_id
            if (! Schema::hasColumn('competition_sessions', 'arena_id')) {

                $table->foreignId('arena_id')
                    ->nullable()
                    ->after('gender')
                    ->constrained('arenas')
                    ->nullOnDelete();
            }
        });

        /*
        |--------------------------------------------------------------------------
        | event_categories
        |--------------------------------------------------------------------------
        */

        Schema::table('event_categories', function (Blueprint $table) {

            if (! Schema::hasColumn('event_categories', 'arena_id')) {

                $table->foreignId('arena_id')
                    ->nullable()
                    ->after('event_id')
                    ->constrained('arenas')
                    ->nullOnDelete();
            }
        });

        /*
        |--------------------------------------------------------------------------
        | contests
        |--------------------------------------------------------------------------
        */

        if (Schema::hasTable('contests')) {

            Schema::table('contests', function (Blueprint $table) {

                if (! Schema::hasColumn('contests', 'arena_id')) {

                    $table->foreignId('arena_id')
                        ->nullable()
                        ->constrained('arenas')
                        ->nullOnDelete();
                }

                if (! Schema::hasColumn('contests', 'competition_session_id')) {

                    $table->foreignId('competition_session_id')
                        ->nullable()
                        ->after('registration_id')
                        ->constrained('competition_sessions')
                        ->nullOnDelete();
                }
            });
        }

        /*
        |--------------------------------------------------------------------------
        | taolu_scores
        |--------------------------------------------------------------------------
        */

        if (! Schema::hasTable('taolu_scores')) {

            Schema::create('taolu_scores', function (Blueprint $table) {

                $table->id();

                $table->foreignId('contest_id')
                    ->unique()
                    ->constrained()
                    ->cascadeOnDelete();

                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::table('competition_sessions', function (Blueprint $table) {

            if (Schema::hasColumn('competition_sessions', 'arena_id')) {

                $table->dropForeign(['arena_id']);
                $table->dropColumn('arena_id');
            }

            if (! Schema::hasColumn('competition_sessions', 'lapangan')) {

                $table->string('lapangan', 50)->nullable();
            }
        });

        Schema::dropIfExists('taolu_scores');
    }
};
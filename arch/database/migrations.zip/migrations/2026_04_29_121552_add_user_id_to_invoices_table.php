<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
   public function up(): void
{
    // Tidak perlu tambah user_id karena tabel sudah pakai coach_id
    // Hanya tambah kolom yang belum ada saja
    Schema::table('invoices', function (Blueprint $table) {

        if (! Schema::hasColumn('invoices', 'invoice_number')) {
            $table->string('invoice_number')->unique()->nullable();
        }

        if (! Schema::hasColumn('invoices', 'status')) {
            $table->enum('status', ['draft', 'sent', 'paid', 'cancelled'])->default('draft');
        }

        if (! Schema::hasColumn('invoices', 'total_amount')) {
            $table->decimal('total_amount', 12, 2)->default(0);
        }

        if (! Schema::hasColumn('invoices', 'paid_at')) {
            $table->timestamp('paid_at')->nullable();
        }
    });
}

    public function down(): void
    {
        Schema::table('invoices', function (Blueprint $table) {
            $columns = ['user_id', 'invoice_number', 'status', 'total_amount', 'paid_at'];

            $toDrop = array_filter(
                $columns,
                fn($col) => Schema::hasColumn('invoices', $col)
            );

            if (! empty($toDrop)) {
                $table->dropColumn(array_values($toDrop));
            }
        });
    }
};
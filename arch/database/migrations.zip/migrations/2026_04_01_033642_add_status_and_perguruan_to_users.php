<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    // public function up(): void
    // {
    //     Schema::table('users', function (Blueprint $table) {
    //         //
    //     });
    // }

    public function up(): void
{
    Schema::table('users', function (Blueprint $table) {
        // $table->string('status')->default('pending');
        $table->foreignId('perguruan_id')
              ->nullable()
              ->constrained()
              ->nullOnDelete();
    });
}
    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            //
        });
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // ═══════════════════════════════════════════════════
        // TABEL: invoices
        // ═══════════════════════════════════════════════════

        if (! Schema::hasTable('invoices')) {
            Schema::create('invoices', function (Blueprint $table) {
                $table->id();
                $table->foreignId('user_id')
                      ->constrained('users')
                      ->restrictOnDelete();
                $table->string('invoice_number', 50)->unique();
                $table->decimal('total_amount', 10, 2)->default(0);
                $table->enum('status', ['draft', 'sent', 'paid', 'cancelled'])->default('draft');
                $table->date('due_date')->nullable();
                $table->timestamp('paid_at')->nullable();
                $table->text('notes')->nullable();
                $table->timestamps();

                // $table->index('user_id');
                $table->index('user_id');
                $table->index('status');
                $table->index('due_date');
            });
        } else {
            // Tabel sudah ada — tambahkan kolom yang mungkin belum ada
            Schema::table('invoices', function (Blueprint $table) {
                if (! Schema::hasColumn('invoices', 'user_id')) {
                    $table->foreignId('user_id')->after('id')->constrained('users')->restrictOnDelete();
                }
                if (! Schema::hasColumn('invoices', 'invoice_number')) {
                    $table->string('invoice_number', 50)->unique()->after('user_id');
                }
                if (! Schema::hasColumn('invoices', 'total_amount')) {
                    $table->decimal('total_amount', 10, 2)->default(0)->after('invoice_number');
                }
                if (! Schema::hasColumn('invoices', 'status')) {
                    $table->enum('status', ['draft', 'sent', 'paid', 'cancelled'])->default('draft')->after('total_amount');
                }
                if (! Schema::hasColumn('invoices', 'due_date')) {
                    $table->date('due_date')->nullable()->after('status');
                }
                if (! Schema::hasColumn('invoices', 'paid_at')) {
                    $table->timestamp('paid_at')->nullable()->after('due_date');
                }
                if (! Schema::hasColumn('invoices', 'notes')) {
                    $table->text('notes')->nullable()->after('paid_at');
                }
            });
        }

        // ═══════════════════════════════════════════════════
        // TABEL: invoice_items
        // ═══════════════════════════════════════════════════

        if (! Schema::hasTable('invoice_items')) {
            Schema::create('invoice_items', function (Blueprint $table) {
                $table->id();
                $table->foreignId('invoice_id')->constrained('invoices')->cascadeOnDelete();
                $table->foreignId('athlete_id')->constrained('athletes')->restrictOnDelete();
                $table->foreignId('event_participant_id')->constrained('event_participants')->restrictOnDelete();
                $table->foreignId('discipline_id')->constrained('disciplines')->restrictOnDelete();
                $table->decimal('price', 10, 2);
                $table->timestamps();

                $table->index('invoice_id');
                $table->index('athlete_id');
                $table->index('event_participant_id');
                $table->unique(['invoice_id', 'athlete_id', 'event_participant_id'], 'invoice_items_unique');
            });
        } else {
            // Tabel sudah ada — handle kolom yang perlu diupdate
            Schema::table('invoice_items', function (Blueprint $table) {
                if (! Schema::hasColumn('invoice_items', 'invoice_id')) {
                    $table->foreignId('invoice_id')->after('id')->constrained('invoices')->cascadeOnDelete();
                }
                if (! Schema::hasColumn('invoice_items', 'athlete_id')) {
                    $table->foreignId('athlete_id')->after('invoice_id')->constrained('athletes')->restrictOnDelete();
                }
                if (Schema::hasColumn('invoice_items', 'event_participant_id')
                    && ! Schema::hasColumn('invoice_items', 'event_participant_id')) {
                    $table->dropConstrainedForeignId('event_participant_id');
                }
                if (! Schema::hasColumn('invoice_items', 'event_participant_id')) {
                    $table->foreignId('event_participant_id')->after('athlete_id')->constrained('event_participants')->restrictOnDelete();
                }
                if (! Schema::hasColumn('invoice_items', 'discipline_id')) {
                    $table->foreignId('discipline_id')->after('event_participant_id')->constrained('disciplines')->restrictOnDelete();
                }
                if (! Schema::hasColumn('invoice_items', 'price')) {
                    $table->decimal('price', 10, 2)->after('discipline_id');
                }
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('invoice_items');
        Schema::dropIfExists('invoices');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('contest_results', function (Blueprint $table) {
            $table->id();
            // $table->foreignId('contest_id')->unique()->constrained('contests')->cascadeOnDelete();
            $table->decimal('final_score', 8, 3)->nullable(); // From avg judge scores
            $table->integer('final_rank')->nullable();
            $table->enum('result_type', ['win', 'loss', 'cancelled'])->nullable(); // Solo: always 'win' or cancelled
            $table->text('notes')->nullable();
            $table->foreignId('recorded_by')->constrained('users')->restrictOnDelete();
            $table->timestamps();

            $table->index('final_rank');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('contest_results');
    }
};


<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('event_participants', function (Blueprint $table) {
            if (! Schema::hasColumn('event_participants', 'event_category_id')) {
                $table->foreignId('event_category_id')
                      ->nullable()
                      ->after('id')
                      ->constrained('event_categories')
                      ->cascadeOnDelete();

                $table->index('event_category_id');
            }

            // Update unique constraint: satu athlete satu slot per event_category
            // Drop unique lama dulu
            $table->dropUnique('event_participants_unique');

            // Tambah unique baru yang include event_category_id
            $table->unique(
                ['event_category_id', 'athlete_id'],
                'event_participants_unique'
            );
        });
    }

    public function down(): void
    {
        Schema::table('event_participants', function (Blueprint $table) {
            $table->dropUnique('event_participants_unique');
            $table->unique(['registration_id', 'athlete_id'], 'event_participants_unique');

            if (Schema::hasColumn('event_participants', 'event_category_id')) {
                $table->dropForeign(['event_category_id']);
                $table->dropColumn('event_category_id');
            }
        });
    }
};
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
                Schema::create('invoices', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')     // FK ke users (role: coach)
                ->constrained('users')
                ->restrictOnDelete();
            $table->string('invoice_number', 50)->unique();
            $table->decimal('total_amount', 10, 2)->default(0);
            $table->enum('status', ['draft', 'sent', 'paid', 'cancelled'])
                ->default('draft');
            $table->date('due_date')->nullable();
            $table->timestamp('paid_at')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
        });

        Schema::create('invoice_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('invoice_id')->constrained()->cascadeOnDelete();
            $table->foreignId('athlete_id')->constrained()->restrictOnDelete();
            $table->foreignId('event_participant_id')->constrained()->restrictOnDelete();
            $table->decimal('price', 10, 2);
            $table->timestamps();
        });
        // Schema::create('invoices', function (Blueprint $table) {
        //     $table->id();
        //     // $table->foreignId('coach_id')->constrained('coaches')->cascadeOnDelete();
        //     $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
        //     $table->string('invoice_number')->unique(); // e.g. INV-2024-0001
        //     $table->decimal('total_amount', 12, 2)->default(0);
        //     $table->enum('status', ['unpaid', 'paid', 'cancelled'])->default('unpaid');
        //     $table->date('due_date')->nullable();
        //     $table->timestamp('paid_at')->nullable();
        //     $table->text('notes')->nullable();
        //     $table->timestamps();
        // });

        // Schema::create('invoice_items', function (Blueprint $table) {
        //     $table->id();
        //     $table->foreignId('invoice_id')->constrained('invoices')->cascadeOnDelete();
        //     $table->foreignId('registration_id')->constrained('registrations')->cascadeOnDelete();
        //     $table->foreignId('athlete_id')->constrained('athletes')->cascadeOnDelete();
        //     $table->foreignId('discipline_id')->constrained('disciplines')->cascadeOnDelete();
        //     // Snapshot harga saat registrasi — tidak ikut berubah kalau harga discipline diupdate
        //     $table->decimal('price', 12, 2);
        //     $table->timestamps();
        // });
    }

    public function down(): void
    {
        Schema::dropIfExists('invoice_items');
        Schema::dropIfExists('invoices');
    }
};

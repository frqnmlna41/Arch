<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('competition_sessions', function (Blueprint $table) {
            $table->id();

            $table->foreignId('event_category_id')->constrained()->cascadeOnDelete();
            $table->enum('gender', ['male', 'female', 'mixed']);

            $table->string('lapangan', 50);            // Mat A, Gelanggang 1, dll
            $table->dateTime('start_time');            // Waktu sesi dimulai
            $table->unsignedSmallInteger('duration_per_athlete')->default(4); // menit
            $table->text('notes')->nullable();

            $table->enum('status', ['draft', 'ongoing', 'done'])->default('draft');
            $table->timestamps();

            // Satu kombinasi hanya boleh punya satu sesi aktif
            $table->unique(['event_category_id', 'gender'], 'unique_session_per_category_gender');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('competition_sessions');
    }
};
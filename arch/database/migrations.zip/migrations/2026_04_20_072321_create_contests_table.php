<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('contests', function (Blueprint $table) {
            
            // Hapus gelanggang & start_time dari contests — pindah ke session
            if (Schema::hasColumn('contests', 'gelanggang')) {
                $table->dropColumn('gelanggang');
            }
            if (Schema::hasColumn('contests', 'start_time')) {
                $table->dropColumn('start_time');
            }
        });
    }

    public function down(): void
    {
        Schema::table('contests', function (Blueprint $table) {
            $table->dropForeign(['competition_session_id']);
            $table->dropColumn('competition_session_id');
            $table->string('gelanggang', 50)->nullable();
            $table->dateTime('start_time')->nullable();
        });
    }
};
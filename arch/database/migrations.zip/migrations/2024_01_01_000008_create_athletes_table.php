<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * Migration: 2024_01_01_000008_create_athletes_table
     *
     * Command: php artisan make:migration create_athletes_table
     *
     * Catatan:
     * - coach_id merujuk ke users dengan role 'coach'
     * - Seorang coach bisa mendaftarkan banyak atlet
     * - Atlet bisa juga memiliki akun user (nullable user_id)
     */
 public function up(): void
{
    // 1. Tabel athletes
    Schema::create('athletes', function (Blueprint $table) {
        $table->id();
        $table->foreignId('user_id')
            ->nullable()
            ->constrained('users')
            ->nullOnDelete()
            ->comment('Akun user milik atlet (opsional)');
        $table->foreignId('coach_id')
            ->nullable()
            ->constrained('users')
            ->nullOnDelete()
            ->comment('Coach yang mendaftarkan atlet ini');
            // $table->unsignedBigInteger('perguruan_id')->nullable();
        $table->foreignId('perguruan_id')
            ->nullable()
            ->constrained('perguruans') // ✅ bukan 'users'
            ->nullOnDelete()
            ->comment('Perguruan tempat atlet terdaftar');
        $table->string('name', 150);
        $table->date('birth_date');
        $table->enum('gender', ['male', 'female']);
        $table->string('club', 150)->nullable();
        $table->string('phone', 20)->nullable();
        $table->string('photo')->nullable();
        $table->string('id_card_number', 50)->nullable();
        $table->decimal('weight', 5, 2)->nullable();
        $table->decimal('height', 5, 2)->nullable();
        $table->text('address')->nullable();
        $table->boolean('is_active')->default(true);
        $table->timestamps();
        $table->softDeletes();

        $table->index(['coach_id', 'is_active']);
        $table->index('perguruan_id');
        $table->index('user_id');
        $table->index('gender');
        $table->index('name');
        $table->index('birth_date');
    });

    // 2. Pivot: satu atlet bisa banyak disiplin + age category
    Schema::create('athlete_discipline', function (Blueprint $table) {
        $table->id();
        $table->foreignId('athlete_id')
            ->constrained('athletes')
            ->cascadeOnDelete();
        $table->foreignId('discipline_id')
            ->constrained('disciplines')
            ->cascadeOnDelete();
        $table->foreignId('age_category_id')
            ->constrained('age_categories')
            ->cascadeOnDelete();
        $table->timestamps();

        // Atlet tidak bisa daftar kombinasi yang sama dua kali
        $table->unique(['athlete_id', 'discipline_id', 'age_category_id']);
    });
}

public function down(): void
{
    Schema::dropIfExists('athlete_discipline');
    Schema::dropIfExists('athletes');
}
};

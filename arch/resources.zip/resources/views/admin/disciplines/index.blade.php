@extends('layouts.admin')

@section('title', 'Discipline Management')

@section('content')
    <div class="container-fluid">

        {{-- Header --}}
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="mb-0">Discipline Management</h1>
                <small class="text-muted">Kelola semua disiplin olahraga</small>
            </div>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createModal">
                <i class="fas fa-plus me-1"></i> Tambah Discipline
            </button>
        </div>

        @include('components._alerts')

        {{-- Filter --}}
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" action="{{ route('admin.disciplines.index') }}" class="row g-2 align-items-end">
                    <div class="col-md-3">
                        <label class="form-label form-label-sm">Cari Nama</label>
                        <input type="text" name="search" class="form-control form-control-sm"
                            placeholder="Cari discipline..." value="{{ request('search') }}">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label form-label-sm">Sport</label>
                        <select name="sport_id" class="form-select form-select-sm">
                            <option value="">-- Semua Sport --</option>
                            @foreach ($sports as $sport)
                                <option value="{{ $sport->id }}"
                                    {{ request('sport_id') == $sport->id ? 'selected' : '' }}>
                                    {{ $sport->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label form-label-sm">Type</label>
                        <select name="type" class="form-select form-select-sm">
                            <option value="">-- Semua Type --</option>
                            <option value="performance" {{ request('type') == 'performance' ? 'selected' : '' }}>Performance
                            </option>
                            <option value="duel" {{ request('type') == 'duel' ? 'selected' : '' }}>Duel</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label form-label-sm">Match Type</label>
                        <select name="match_type" class="form-select form-select-sm">
                            <option value="">-- Semua --</option>
                            <option value="sanda" {{ request('match_type') == 'sanda' ? 'selected' : '' }}>Sanda
                            </option>
                            <option value="sparring" {{ request('match_type') == 'sparring' ? 'selected' : '' }}>Sparring
                            </option>
                            <option value="solo" {{ request('match_type') == 'solo' ? 'selected' : '' }}>Solo</option>
                        </select>
                    </div>
                    <div class="col-md-1">
                        <label class="form-label form-label-sm">Aktif</label>
                        <div class="form-check form-switch mt-1">
                            <input class="form-check-input" type="checkbox" name="active" value="1"
                                {{ request('active') ? 'checked' : '' }}>
                        </div>
                    </div>
                    <div class="col-md-2 d-flex gap-1">
                        <button type="submit" class="btn btn-outline-secondary btn-sm flex-fill">
                            <i class="fas fa-search"></i> Filter
                        </button>
                        <a href="{{ route('admin.disciplines.index') }}" class="btn btn-outline-danger btn-sm"
                            title="Reset">
                            <i class="fas fa-times"></i>
                        </a>
                    </div>
                </form>
            </div>
        </div>

        {{-- Tabel --}}
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="fas fa-list me-2"></i>Daftar Discipline</h5>
                <span class="badge bg-secondary">{{ $disciplines->total() }} discipline</span>
            </div>
            <div class="card-body p-0">
                @if ($disciplines->isEmpty())
                    <div class="text-center py-5 text-muted">
                        <i class="fas fa-inbox fa-3x mb-3"></i>
                        <p>Belum ada discipline. <a href="#" data-bs-toggle="modal"
                                data-bs-target="#createModal">Tambah sekarang</a>.</p>
                    </div>
                @else
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered mb-0 align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th width="50">No</th>
                                    <th>Nama</th>
                                    <th>Sport</th>
                                    <th>Type</th>
                                    <th>Match Type</th>
                                    <th>Kategori Usia</th>
                                    <th>Status</th>
                                    <th width="130">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($disciplines as $i => $discipline)
                                    <tr>
                                        <td class="text-center">{{ $disciplines->firstItem() + $i }}</td>
                                        <td>
                                            <strong>{{ $discipline->name }}</strong>
                                            @if ($discipline->description)
                                                <br><small
                                                    class="text-muted">{{ Str::limit($discipline->description, 60) }}</small>
                                            @endif
                                        </td>
                                        <td>{{ $discipline->sport?->name ?? '-' }}</td>
                                        <td>
                                            @if ($discipline->type === 'performance')
                                                <span class="badge bg-info text-dark">Performance</span>
                                            @elseif($discipline->type === 'duel')
                                                <span class="badge bg-danger">Duel</span>
                                            @else
                                                <span class="badge bg-secondary">{{ $discipline->type ?? '-' }}</span>
                                            @endif
                                        </td>
                                        <td>
                                            <span class="badge bg-secondary">
                                                {{ ucfirst($discipline->match_type ?? '-') }}
                                            </span>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-primary">
                                                {{ $discipline->age_categories_count }} kategori
                                            </span>
                                        </td>
                                        <td class="text-center">
                                            @if ($discipline->is_active)
                                                <span class="badge bg-success">Aktif</span>
                                            @else
                                                <span class="badge bg-secondary">Nonaktif</span>
                                            @endif
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <button class="btn btn-sm btn-info btn-show"
                                                    data-id="{{ $discipline->id }}" title="Detail">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <button class="btn btn-sm btn-warning btn-edit"
                                                    data-discipline="{{ json_encode([
                                                        'id' => $discipline->id,
                                                        'name' => $discipline->name,
                                                        'sport_id' => $discipline->sport_id,
                                                        'type' => $discipline->type,
                                                        'match_type' => $discipline->match_type,
                                                        'description' => $discipline->description,
                                                        'is_active' => $discipline->is_active,
                                                        'age_categories' => $discipline->ageCategories->pluck('id'),
                                                    ]) }}"
                                                    title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="btn btn-sm btn-danger btn-delete"
                                                    data-id="{{ $discipline->id }}" data-name="{{ $discipline->name }}"
                                                    title="Hapus">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="p-3">
                        {{ $disciplines->appends(request()->query())->links() }}
                    </div>
                @endif
            </div>
        </div>
    </div>

    {{-- ==================== MODAL CREATE ==================== --}}
    <div class="modal fade" id="createModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-plus me-2"></i>Tambah Discipline</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    @include('admin.disciplines._form', ['mode' => 'create'])
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="button" class="btn btn-primary" onclick="submitCreate()">
                        <i class="fas fa-save me-1"></i> Simpan
                    </button>
                </div>
            </div>
        </div>
    </div>

    {{-- ==================== MODAL EDIT ==================== --}}
    <div class="modal fade" id="editModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Edit Discipline</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="editModalBody"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="button" class="btn btn-warning" onclick="submitEdit()">
                        <i class="fas fa-save me-1"></i> Update
                    </button>
                </div>
            </div>
        </div>
    </div>

    {{-- ==================== MODAL DETAIL ==================== --}}
    <div class="modal fade" id="showModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-eye me-2"></i>Detail Discipline</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="showModalBody">
                    <div class="text-center py-4">
                        <div class="spinner-border text-primary"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        const CSRF = document.querySelector('meta[name="csrf-token"]').content;

        // ── SHOW DETAIL ──
        document.querySelectorAll('.btn-show').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.dataset.id;
                document.getElementById('showModalBody').innerHTML =
                    '<div class="text-center py-4"><div class="spinner-border text-primary"></div></div>';
                new bootstrap.Modal(document.getElementById('showModal')).show();

                fetch(`/admin/disciplines/${id}`, {
                        headers: {
                            'Accept': 'application/json',
                            'X-CSRF-TOKEN': CSRF
                        }
                    })
                    .then(r => r.json())
                    .then(res => {
                        if (res.status !== 'success') {
                            alert(res.message);
                            return;
                        }
                        const d = res.data;
                        const ageList = d.age_categories?.map(a =>
                            `<span class="badge bg-primary me-1">${a.name}</span>`).join('') || '-';
                        document.getElementById('showModalBody').innerHTML = `
                <table class="table table-borderless mb-0">
                    <tr><th width="160">Nama</th><td>${d.name}</td></tr>
                    <tr><th>Sport</th><td>${d.sport?.name ?? '-'}</td></tr>
                    <tr><th>Type</th><td>${d.type ?? '-'}</td></tr>
                    <tr><th>Match Type</th><td>${d.match_type ?? '-'}</td></tr>
                    <tr><th>Deskripsi</th><td>${d.description ?? '-'}</td></tr>
                    <tr><th>Kategori Usia</th><td>${ageList}</td></tr>
                    <tr><th>Status</th>
                        <td><span class="badge ${d.is_active ? 'bg-success' : 'bg-secondary'}">
                            ${d.is_active ? 'Aktif' : 'Nonaktif'}
                        </span></td>
                    </tr>
                </table>
            `;
                    });
            });
        });

        // ── EDIT ──
        document.querySelectorAll('.btn-edit').forEach(btn => {
            btn.addEventListener('click', function() {
                const d = JSON.parse(this.dataset.discipline);
                document.getElementById('editModalBody').innerHTML = buildEditForm(d);
                new bootstrap.Modal(document.getElementById('editModal')).show();
            });
        });

        function buildEditForm(d) {
            const sports = @json($sports);
            const ageCategories = @json($ageCategories);
            const selectedAges = d.age_categories ?? [];

            const sportOptions = sports.map(s =>
                `<option value="${s.id}" ${d.sport_id == s.id ? 'selected' : ''}>${s.name}</option>`
            ).join('');

            const ageOptions = ageCategories.map(a =>
                `<option value="${a.id}" ${selectedAges.includes(a.id) ? 'selected' : ''}>${a.name}</option>`
            ).join('');

            return `
        <input type="hidden" id="editId" value="${d.id}">
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Nama <span class="text-danger">*</span></label>
                <input type="text" id="editName" class="form-control" value="${d.name}" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Sport <span class="text-danger">*</span></label>
                <select id="editSportId" class="form-select" required>
                    <option value="">-- Pilih Sport --</option>
                    ${sportOptions}
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Type <span class="text-danger">*</span></label>
                <select id="editType" class="form-select" required>
                    <option value="performance" ${d.type === 'performance' ? 'selected' : ''}>Performance</option>
                    <option value="duel"        ${d.type === 'duel'        ? 'selected' : ''}>Duel</option>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Match Type</label>
                <select id="editMatchType" class="form-select">
                    <option value="">-- Pilih --</option>
                    <option value="sanda"    ${d.match_type === 'sanda'    ? 'selected' : ''}>Sanda</option>
                    <option value="sparring" ${d.match_type === 'sparring' ? 'selected' : ''}>Sparring</option>
                    <option value="solo"     ${d.match_type === 'solo'     ? 'selected' : ''}>Solo</option>
                </select>
            </div>
            <div class="col-12">
                <label class="form-label">Deskripsi</label>
                <textarea id="editDescription" class="form-control" rows="3">${d.description ?? ''}</textarea>
            </div>
            <div class="col-12">
                <label class="form-label">Kategori Usia</label>
                <select id="editAgeCategories" class="form-select" multiple>
                    ${ageOptions}
                </select>
                <small class="text-muted">Tahan Ctrl untuk pilih lebih dari satu</small>
            </div>
            <div class="col-12">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" id="editIsActive"
                           ${d.is_active ? 'checked' : ''}>
                    <label class="form-check-label" for="editIsActive">Aktif</label>
                </div>
            </div>
        </div>
    `;
        }

        function submitEdit() {
            const id = document.getElementById('editId').value;
            const ageCategoryIds = Array.from(
                document.getElementById('editAgeCategories').selectedOptions
            ).map(o => o.value);

            fetch(`/admin/disciplines/${id}`, {
                    method: 'PATCH',
                    headers: {
                        'X-CSRF-TOKEN': CSRF,
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        name: document.getElementById('editName').value,
                        sport_id: document.getElementById('editSportId').value,
                        type: document.getElementById('editType').value,
                        match_type: document.getElementById('editMatchType').value,
                        description: document.getElementById('editDescription').value,
                        is_active: document.getElementById('editIsActive').checked,
                        age_category_ids: ageCategoryIds,
                    })
                })
                .then(r => r.json())
                .then(data => {
                    alert(data.message);
                    if (data.status === 'success') location.reload();
                });
        }

        // ── CREATE ──
        function submitCreate() {
            const form = document.getElementById('createForm');
            const ageCategoryIds = Array.from(
                form.querySelectorAll('[name="age_category_ids[]"] option:checked')
            ).map(o => o.value);

            fetch('/admin/disciplines', {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': CSRF,
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        name: form.querySelector('[name=name]').value,
                        sport_id: form.querySelector('[name=sport_id]').value,
                        type: form.querySelector('[name=type]').value,
                        match_type: form.querySelector('[name=match_type]').value,
                        description: form.querySelector('[name=description]').value,
                        is_active: form.querySelector('[name=is_active]').checked,
                        age_category_ids: ageCategoryIds,
                    })
                })
                .then(r => r.json())
                .then(data => {
                    alert(data.message);
                    if (data.status === 'success') location.reload();
                });
        }

        // ── DELETE ──
        document.querySelectorAll('.btn-delete').forEach(btn => {
            btn.addEventListener('click', function() {
                if (!confirm(`Hapus discipline "${this.dataset.name}"?`)) return;

                fetch(`/admin/disciplines/${this.dataset.id}`, {
                        method: 'DELETE',
                        headers: {
                            'X-CSRF-TOKEN': CSRF,
                            'Accept': 'application/json'
                        }
                    })
                    .then(r => r.json())
                    .then(data => {
                        alert(data.message);
                        if (data.status === 'success') location.reload();
                    });
            });
        });
    </script>
@endsection

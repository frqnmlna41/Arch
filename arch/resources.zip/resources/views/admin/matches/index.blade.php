@extends('layouts.admin')

@section('title', 'Match Management')

@section('content')
    <div class="container-fluid">

        {{-- Header --}}
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="mb-0">Match Management</h1>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createMatchModal">
                <i class="fas fa-plus me-1"></i> Tambah Match
            </button>
        </div>

        @include('components._alerts')

        {{-- Filter --}}
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" action="{{ route('admin.matches.index') }}" class="row g-2">
                    <div class="col-md-3">
                        <select name="event_id" class="form-select form-select-sm">
                            <option value="">-- Semua Event --</option>
                            @foreach ($events as $event)
                                <option value="{{ $event->id }}"
                                    {{ request('event_id') == $event->id ? 'selected' : '' }}>
                                    {{ $event->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select name="status" class="form-select form-select-sm">
                            <option value="">-- Semua Status --</option>
                            <option value="scheduled" {{ request('status') == 'scheduled' ? 'selected' : '' }}>Scheduled
                            </option>
                            <option value="ongoing" {{ request('status') == 'ongoing' ? 'selected' : '' }}>Ongoing
                            </option>
                            <option value="completed" {{ request('status') == 'completed' ? 'selected' : '' }}>Completed
                            </option>
                            <option value="cancelled" {{ request('status') == 'cancelled' ? 'selected' : '' }}>Cancelled
                            </option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <input type="date" name="date" class="form-control form-control-sm"
                            value="{{ request('date') }}" placeholder="Tanggal">
                    </div>
                    <div class="col-md-2">
                        <select name="round" class="form-select form-select-sm">
                            <option value="">-- Semua Ronde --</option>
                            <option value="pool" {{ request('round') == 'pool' ? 'selected' : '' }}>Pool</option>
                            <option value="quarter_final" {{ request('round') == 'quarter_final' ? 'selected' : '' }}>
                                Quarter Final</option>
                            <option value="semi_final" {{ request('round') == 'semi_final' ? 'selected' : '' }}>Semi
                                Final</option>
                            <option value="final" {{ request('round') == 'final' ? 'selected' : '' }}>Final
                            </option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-outline-secondary btn-sm w-100">
                            <i class="fas fa-search me-1"></i> Filter
                        </button>
                    </div>
                    <div class="col-md-1">
                        <a href="{{ route('admin.matches.index') }}" class="btn btn-outline-danger btn-sm w-100"
                            title="Reset">
                            <i class="fas fa-times"></i>
                        </a>
                    </div>
                </form>
            </div>
        </div>

        {{-- Generate Bracket --}}
        <div class="card mb-4 border-warning">
            <div class="card-header bg-warning bg-opacity-10">
                <h6 class="mb-0"><i class="fas fa-sitemap me-2 text-warning"></i> Generate Bracket Otomatis</h6>
            </div>
            <div class="card-body">
                <form id="generateForm" class="row g-2 align-items-end">
                    @csrf
                    <div class="col-md-3">
                        <label class="form-label form-label-sm">Event</label>
                        <select name="event_id" id="genEventId" class="form-select form-select-sm" required>
                            <option value="">-- Pilih Event --</option>
                            @foreach ($events as $event)
                                <option value="{{ $event->id }}">{{ $event->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label form-label-sm">Disiplin</label>
                        <select name="discipline_id" class="form-select form-select-sm" required>
                            <option value="">-- Pilih Disiplin --</option>
                            @foreach ($disciplines as $d)
                                <option value="{{ $d->id }}">{{ $d->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label form-label-sm">Kategori Usia</label>
                        <select name="age_category_id" class="form-select form-select-sm" required>
                            <option value="">-- Pilih Kategori --</option>
                            @foreach ($ageCategories as $ac)
                                <option value="{{ $ac->id }}">{{ $ac->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button type="button" onclick="generateBracket()" class="btn btn-warning btn-sm w-100">
                            <i class="fas fa-sitemap me-1"></i> Generate
                        </button>
                    </div>
                </form>
            </div>
        </div>

        {{-- Tabel Match --}}
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="fas fa-table me-2"></i> Daftar Pertandingan</h5>
                <span class="badge bg-secondary">{{ $matches->total() }} pertandingan</span>
            </div>
            <div class="card-body p-0">
                @if ($matches->isEmpty())
                    <p class="text-muted text-center py-5">Belum ada pertandingan.</p>
                @else
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered mb-0 align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>No</th>
                                    <th>Event</th>
                                    <th>Disiplin</th>
                                    <th>Ronde</th>
                                    <th>Atlet 1</th>
                                    <th>Atlet 2</th>
                                    <th>Arena</th>
                                    <th>Tanggal & Waktu</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($matches as $i => $match)
                                    <tr>
                                        <td>{{ $matches->firstItem() + $i }}</td>
                                        <td>{{ $match->event?->name ?? '-' }}</td>
                                        <td>{{ $match->discipline?->name ?? '-' }}</td>
                                        <td>
                                            <span class="badge bg-secondary">
                                                {{ str_replace('_', ' ', ucfirst($match->round ?? '-')) }}
                                            </span>
                                        </td>
                                        <td>{{ $match->athlete1?->name ?? '-' }}</td>
                                        <td>{{ $match->athlete2?->name ?? 'BYE' }}</td>
                                        <td>
                                            @if ($match->arena)
                                                <span class="badge bg-info text-dark">{{ $match->arena->name }}</span>
                                            @else
                                                <span class="text-muted">-</span>
                                            @endif
                                        </td>
                                        <td>
                                            @if ($match->match_date)
                                                {{ \Carbon\Carbon::parse($match->match_date)->format('d M Y') }}
                                                <br><small class="text-muted">{{ $match->match_time ?? '-' }}</small>
                                            @else
                                                <span class="text-muted">Belum dijadwalkan</span>
                                            @endif
                                        </td>
                                        <td>
                                            @php
                                                $badgeClass = match ($match->status) {
                                                    'scheduled' => 'bg-primary',
                                                    'ongoing' => 'bg-warning text-dark',
                                                    'completed' => 'bg-success',
                                                    'cancelled' => 'bg-danger',
                                                    default => 'bg-secondary',
                                                };
                                            @endphp
                                            <span class="badge {{ $badgeClass }}">
                                                {{ ucfirst($match->status ?? '-') }}
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="{{ route('admin.matches.show', $match) }}"
                                                    class="btn btn-sm btn-info" title="Detail">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <button class="btn btn-sm btn-secondary btn-schedule"
                                                    data-id="{{ $match->id }}" data-date="{{ $match->match_date }}"
                                                    data-time="{{ $match->match_time }}" title="Jadwalkan">
                                                    <i class="fas fa-calendar"></i>
                                                </button>
                                                <button class="btn btn-sm btn-dark btn-arena"
                                                    data-id="{{ $match->id }}" data-arena="{{ $match->arena_id }}"
                                                    title="Assign Arena">
                                                    <i class="fas fa-map-marker-alt"></i>
                                                </button>
                                                @if (!in_array($match->status, ['ongoing', 'completed']))
                                                    <button class="btn btn-sm btn-warning btn-edit"
                                                        data-match="{{ json_encode($match) }}" title="Edit">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <button class="btn btn-sm btn-danger btn-delete"
                                                        data-id="{{ $match->id }}"
                                                        data-num="{{ $match->match_number }}" title="Hapus">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                @endif
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="p-3">
                        {{ $matches->appends(request()->query())->links() }}
                    </div>
                @endif
            </div>
        </div>
    </div>

    {{-- ===================== MODALS ===================== --}}

    {{-- Modal Create Match --}}
    <div class="modal fade" id="createMatchModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-plus me-2"></i>Tambah Match</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    @include('admin.matches._form', ['match' => null])
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="button" class="btn btn-primary" onclick="submitCreateMatch()">Simpan</button>
                </div>
            </div>
        </div>
    </div>

    {{-- Modal Edit Match --}}
    <div class="modal fade" id="editMatchModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Edit Match</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="editMatchBody"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="button" class="btn btn-warning" onclick="submitEditMatch()">Update</button>
                </div>
            </div>
        </div>
    </div>

    {{-- Modal Assign Jadwal --}}
    <div class="modal fade" id="scheduleModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-calendar me-2"></i>Assign Jadwal</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="scheduleMatchId">
                    <div class="mb-3">
                        <label class="form-label">Tanggal</label>
                        <input type="date" id="scheduleDate" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Waktu</label>
                        <input type="time" id="scheduleTime" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="button" class="btn btn-primary" onclick="submitSchedule()">Simpan</button>
                </div>
            </div>
        </div>
    </div>

    {{-- Modal Assign Arena --}}
    <div class="modal fade" id="arenaModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-map-marker-alt me-2"></i>Assign Arena</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="arenaMatchId">
                    <div class="mb-3">
                        <label class="form-label">Pilih Arena</label>
                        <select id="arenaSelect" class="form-select" required>
                            <option value="">-- Pilih Arena --</option>
                            @foreach ($arenas as $arena)
                                <option value="{{ $arena->id }}">{{ $arena->name }} — {{ $arena->location }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="button" class="btn btn-dark" onclick="submitArena()">Assign</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        const CSRF = document.querySelector('meta[name="csrf-token"]').content;

        // ── Generate Bracket ──
        function generateBracket() {
            const form = document.getElementById('generateForm');
            const eventId = form.querySelector('[name=event_id]').value;
            const disciplineId = form.querySelector('[name=discipline_id]').value;
            const ageCategoryId = form.querySelector('[name=age_category_id]').value;

            if (!eventId || !disciplineId || !ageCategoryId) {
                alert('Lengkapi semua field generate bracket.');
                return;
            }

            fetch(`/admin/matches/generate/${eventId}`, {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': CSRF,
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        discipline_id: disciplineId,
                        age_category_id: ageCategoryId
                    })
                })
                .then(r => r.json())
                .then(data => {
                    alert(data.message);
                    if (data.status === 'success') location.reload();
                });
        }

        // ── Assign Jadwal ──
        document.querySelectorAll('.btn-schedule').forEach(btn => {
            btn.addEventListener('click', function() {
                document.getElementById('scheduleMatchId').value = this.dataset.id;
                document.getElementById('scheduleDate').value = this.dataset.date ?? '';
                document.getElementById('scheduleTime').value = this.dataset.time ?? '';
                new bootstrap.Modal(document.getElementById('scheduleModal')).show();
            });
        });

        function submitSchedule() {
            const id = document.getElementById('scheduleMatchId').value;
            const date = document.getElementById('scheduleDate').value;
            const time = document.getElementById('scheduleTime').value;

            fetch(`/admin/matches/${id}/schedule`, {
                    method: 'PATCH',
                    headers: {
                        'X-CSRF-TOKEN': CSRF,
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        match_date: date,
                        match_time: time
                    })
                })
                .then(r => r.json())
                .then(data => {
                    alert(data.message);
                    if (data.status === 'success') location.reload();
                });
        }

        // ── Assign Arena ──
        document.querySelectorAll('.btn-arena').forEach(btn => {
            btn.addEventListener('click', function() {
                document.getElementById('arenaMatchId').value = this.dataset.id;
                document.getElementById('arenaSelect').value = this.dataset.arena ?? '';
                new bootstrap.Modal(document.getElementById('arenaModal')).show();
            });
        });

        function submitArena() {
            const id = document.getElementById('arenaMatchId').value;
            const arenaId = document.getElementById('arenaSelect').value;

            if (!arenaId) {
                alert('Pilih arena terlebih dahulu.');
                return;
            }

            fetch(`/admin/matches/${id}/arena`, {
                    method: 'PATCH',
                    headers: {
                        'X-CSRF-TOKEN': CSRF,
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        arena_id: arenaId
                    })
                })
                .then(r => r.json())
                .then(data => {
                    alert(data.message);
                    if (data.status === 'success') location.reload();
                });
        }

        // ── Edit Match ──
        document.querySelectorAll('.btn-edit').forEach(btn => {
            btn.addEventListener('click', function() {
                const match = JSON.parse(this.dataset.match);
                document.getElementById('editMatchBody').innerHTML = buildEditForm(match);
                new bootstrap.Modal(document.getElementById('editMatchModal')).show();
            });
        });

        function buildEditForm(match) {
            return `
        <input type="hidden" id="editMatchId" value="${match.id}">
        <div class="mb-3">
            <label class="form-label">Status</label>
            <select id="editStatus" class="form-select">
                <option value="scheduled" ${match.status === 'scheduled' ? 'selected' : ''}>Scheduled</option>
                <option value="ongoing"   ${match.status === 'ongoing'   ? 'selected' : ''}>Ongoing</option>
                <option value="completed" ${match.status === 'completed' ? 'selected' : ''}>Completed</option>
                <option value="cancelled" ${match.status === 'cancelled' ? 'selected' : ''}>Cancelled</option>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Ronde</label>
            <select id="editRound" class="form-select">
                <option value="pool"          ${match.round === 'pool'          ? 'selected' : ''}>Pool</option>
                <option value="quarter_final" ${match.round === 'quarter_final' ? 'selected' : ''}>Quarter Final</option>
                <option value="semi_final"    ${match.round === 'semi_final'    ? 'selected' : ''}>Semi Final</option>
                <option value="final"         ${match.round === 'final'         ? 'selected' : ''}>Final</option>
            </select>
        </div>
    `;
        }

        function submitEditMatch() {
            const id = document.getElementById('editMatchId').value;
            fetch(`/admin/matches/${id}`, {
                    method: 'PATCH',
                    headers: {
                        'X-CSRF-TOKEN': CSRF,
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        status: document.getElementById('editStatus').value,
                        round: document.getElementById('editRound').value,
                    })
                })
                .then(r => r.json())
                .then(data => {
                    alert(data.message);
                    if (data.status === 'success') location.reload();
                });
        }

        // ── Delete Match ──
        document.querySelectorAll('.btn-delete').forEach(btn => {
            btn.addEventListener('click', function() {
                if (confirm(`Hapus Match #${this.dataset.num}?`)) {
                    fetch(`/admin/matches/${this.dataset.id}`, {
                            method: 'DELETE',
                            headers: {
                                'X-CSRF-TOKEN': CSRF,
                                'Accept': 'application/json'
                            }
                        })
                        .then(r => r.json())
                        .then(data => {
                            alert(data.message);
                            if (data.status === 'success') location.reload();
                        });
                }
            });
        });

        // ── Create Match ──
        function submitCreateMatch() {
            const form = document.getElementById('createMatchForm');
            const formData = new FormData(form);
            const body = Object.fromEntries(formData.entries());

            fetch('/admin/matches', {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': CSRF,
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(body)
                })
                .then(r => r.json())
                .then(data => {
                    alert(data.message);
                    if (data.status === 'success') location.reload();
                });
        }
    </script>
@endsection
